This code was made with claude code as a experiment and edu purposes.
Keep the tournament_pieces and sounds folders beside enginegui.py when running the game.
The standard chess sound pack is stored in sounds\standard.
Keep the staunty_pieces folder beside enginegui.py to use the Staunty piece set.
Keep the merida_pieces folder beside enginegui.py to use the Merida piece set.
Keep the move_rating_icons folder beside enginegui.py to display move-rating icons.
Move ratings are shown on the latest move by each side. The bot randomizes among equally scored moves.

thanks for Magnific for the icon <3

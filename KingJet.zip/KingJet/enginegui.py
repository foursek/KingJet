from pathlib import Path
import ctypes
import os
import random
import threading
import time
import tkinter as tk

import chess

# ---------------- Engine ----------------
DEPTH = 3  # raise to 4 for a stronger (but slower) engine

PIECE_VALUES = {
    chess.PAWN: 100,
    chess.KNIGHT: 320,
    chess.BISHOP: 330,
    chess.ROOK: 500,
    chess.QUEEN: 900,
    chess.KING: 0,
}


def evaluate(board):
    if board.is_checkmate():
        return -100000
    if board.is_stalemate() or board.is_insufficient_material():
        return 0
    score = 0
    for piece_type, value in PIECE_VALUES.items():
        score += len(board.pieces(piece_type, board.turn)) * value
        score -= len(board.pieces(piece_type, not board.turn)) * value
    return score


def ordered_moves(board):
    # Captures first makes alpha-beta much faster
    return sorted(board.legal_moves, key=lambda m: board.is_capture(m), reverse=True)


def negamax(board, depth, alpha, beta):
    if depth == 0 or board.is_game_over():
        return evaluate(board)
    best = -float("inf")
    for move in ordered_moves(board):
        board.push(move)
        score = -negamax(board, depth - 1, -beta, -alpha)
        board.pop()
        best = max(best, score)
        alpha = max(alpha, score)
        if alpha >= beta:
            break
    return best


def best_move(board, depth=DEPTH):
    best_moves = []
    best_score = -float("inf")
    for move in ordered_moves(board):
        board.push(move)
        score = -negamax(board, depth - 1, -float("inf"), float("inf"))
        board.pop()
        if score > best_score:
            best_moves = [move]
            best_score = score
        elif score == best_score:
            best_moves.append(move)
    return random.choice(best_moves) if best_moves else None


OPENING_BOOK_LINES = tuple(
    tuple(chess.Move.from_uci(move) for move in line.split())
    for line in (
        "e2e4 e7e5 g1f3 b8c6 f1b5 a7a6 b5a4 g8f6",
        "e2e4 e7e5 g1f3 b8c6 f1b5 g8f6",
        "e2e4 c7c5 g1f3 d7d6 d2d4 c5d4 f3d4",
        "e2e4 e7e6 d2d4 d7d5 b1c3 g8f6",
        "e2e4 c7c6 d2d4 d7d5 b1c3 d5e4",
        "e2e4 d7d5 e4d5 d8d5 b1c3 d5a5",
        "e2e4 c7c5 b1c3 b8c6 g2g3 g7g6",
        "d2d4 d7d5 c2c4 e7e6 b1c3 g8f6",
        "d2d4 d7d5 c2c4 c7c6 b1c3 g8f6",
        "d2d4 g8f6 c2c4 g7g6 b1c3 f8g7 e2e4 d7d6",
        "d2d4 g8f6 c2c4 e7e6 b1c3 f8b4",
        "g1f3 d7d5 d2d4 g8f6 c2c4",
        "c2c4 e7e5 b1c3 g8f6",
    )
)


def classify_move(board, move, depth=2):
    history = tuple(board.move_stack) + (move,)
    if len(history) <= 12 and any(
        line[:len(history)] == history for line in OPENING_BOOK_LINES
    ):
        return "Book move"

    best_score = -float("inf")
    played_score = None
    for candidate in ordered_moves(board):
        board.push(candidate)
        score = -negamax(board, depth - 1, -float("inf"), float("inf"))
        board.pop()
        best_score = max(best_score, score)
        if candidate == move:
            played_score = score

    if played_score is None:
        raise ValueError(f"Cannot rate illegal move: {move}")
    centipawn_loss = max(0, best_score - played_score)
    if centipawn_loss == 0:
        return "Best"
    if centipawn_loss <= 25:
        return "Excellent"
    if centipawn_loss <= 75:
        return "Good"
    if centipawn_loss <= 150:
        return "Inaccuracy"
    if centipawn_loss <= 300:
        return "Mistake"
    return "Blunder"


MOVE_RATING_ICON_FILES = {
    "Book move": "book.png",
    "Best": "best.png",
    "Excellent": "excellent.png",
    "Good": "good.png",
    "Inaccuracy": "inaccuracy.png",
    "Mistake": "mistake.png",
    "Blunder": "blunder.png",
}


# ---------------- GUI ----------------
SQ = 80                 # square size in pixels (the piece images are made for 80)
SLIDE_MS = 220          # how long a piece takes to slide
FRAME_MS = 15           # animation frame time
BOT_DELAY_MS = 1000     # bot plays this long after your move because else it feels too fast + gives you time to see your move

LIGHT = "#efd8b6"
DARK = "#c5946d"
SELECTED_L, SELECTED_D = "#f7ec6e", "#d9c34a"
LAST_L, LAST_D = "#cdd26a", "#aaa23a"
CHECK = "#e8584f"
INDICATOR = "#333333"   # gray used for the move dots / capture rings
INDICATOR_ALPHA = 0.35  # how strong the "transparent" gray is

BOARD_THEMES = {
    "Classic": {
        "light": LIGHT,
        "dark": DARK,
        "selected_light": SELECTED_L,
        "selected_dark": SELECTED_D,
        "last_light": LAST_L,
        "last_dark": LAST_D,
    },
    "Green": {
        "light": "#eeeed2",
        "dark": "#769656",
        "selected_light": "#f6f669",
        "selected_dark": "#bbcc44",
        "last_light": "#cdd26a",
        "last_dark": "#aaa23a",
    },
    "Blue": {
        "light": "#e6edf5",
        "dark": "#55718e",
        "selected_light": "#f7e889",
        "selected_dark": "#d2b94d",
        "last_light": "#c6d58a",
        "last_dark": "#9cac55",
    },
    "Purple": {
        "light": "#eee5f2",
        "dark": "#8c78a8",
        "selected_light": "#f7e889",
        "selected_dark": "#d2b94d",
        "last_light": "#c6d58a",
        "last_dark": "#9cac55",
    },
    "Slate": {
        "light": "#dce3e8",
        "dark": "#6e8494",
        "selected_light": "#f1e58a",
        "selected_dark": "#c4b65d",
        "last_light": "#c1d5b3",
        "last_dark": "#8ca77a",
    },
    "Walnut": {
        "light": "#f0e2c4",
        "dark": "#9b6b43",
        "selected_light": "#f7eb81",
        "selected_dark": "#d7bd4c",
        "last_light": "#cdd26a",
        "last_dark": "#aaa23a",
    },
    "Rose": {
        "light": "#f3e1e4",
        "dark": "#ba7887",
        "selected_light": "#f7e889",
        "selected_dark": "#d2b94d",
        "last_light": "#c6d58a",
        "last_dark": "#9cac55",
    },
    "Mint": {
        "light": "#e4f1e5",
        "dark": "#70a887",
        "selected_light": "#f5e98a",
        "selected_dark": "#c5b956",
        "last_light": "#c4d99b",
        "last_dark": "#91b26b",
    },
    "Cburnett Brown": {
        "light": "#efd8b3",
        "dark": "#b58863",
        "selected_light": "#f7ec6e",
        "selected_dark": "#d9c34a",
        "last_light": "#cdd26a",
        "last_dark": "#aaa23a",
    },
    "Cburnett Gray": {
        "light": "#d9d9d9",
        "dark": "#8294c4",
        "selected_light": "#f7ec6e",
        "selected_dark": "#d9c34a",
        "last_light": "#cdd26a",
        "last_dark": "#aaa23a",
    },
}

BOARD_TEXTURES = {
    "Cburnett Brown": "brown",
    "Cburnett Gray": "gray",
}

UNICODE_PIECES = {
    chess.KING: {chess.WHITE: "\u2654", chess.BLACK: "\u265a"},
    chess.QUEEN: {chess.WHITE: "\u2655", chess.BLACK: "\u265b"},
    chess.ROOK: {chess.WHITE: "\u2656", chess.BLACK: "\u265c"},
    chess.BISHOP: {chess.WHITE: "\u2657", chess.BLACK: "\u265d"},
    chess.KNIGHT: {chess.WHITE: "\u2658", chess.BLACK: "\u265e"},
    chess.PAWN: {chess.WHITE: "\u2659", chess.BLACK: "\u265f"},
}

PIECE_STYLES = {
    "Unicode": ("Segoe UI Symbol", 52, False, True),
    "Bold Unicode": ("Segoe UI Symbol", 52, True, True),
    "Serif Letters": ("Georgia", 43, True, False),
    "Sans Letters": ("Arial", 43, True, False),
}
PIECE_STYLE_NAMES = (
    "Unicode",
    "Bold Unicode",
    "Tournament",
    "Staunty",
    "Merida",
    "Serif Letters",
    "Sans Letters",
)
def play_mp3(path):
    winmm = ctypes.WinDLL("winmm")
    send_string = winmm.mciSendStringW
    send_string.argtypes = (
        ctypes.c_wchar_p,
        ctypes.c_wchar_p,
        ctypes.c_uint,
        ctypes.c_void_p,
    )
    send_string.restype = ctypes.c_uint
    get_error = winmm.mciGetErrorStringW
    get_error.argtypes = (ctypes.c_uint, ctypes.c_wchar_p, ctypes.c_uint)
    get_error.restype = ctypes.c_int
    alias = f"chess_sound_{threading.get_ident()}"

    def command(text):
        error_code = send_string(text, None, 0, None)
        if error_code:
            message = ctypes.create_unicode_buffer(256)
            get_error(error_code, message, len(message))
            raise RuntimeError(message.value)

    opened = False
    try:
        command(f'open "{path}" type mpegvideo alias {alias}')
        opened = True
        command(f"play {alias} wait")
    finally:
        if opened:
            command(f"close {alias}")


def piece_appearance(piece, style, square_size=SQ):
    family, base_size, bold, use_unicode = PIECE_STYLES[style]
    glyph = (
        UNICODE_PIECES[piece.piece_type][piece.color]
        if use_unicode else piece.symbol().upper()
    )
    font = (family, max(8, round(base_size * square_size / SQ)))
    if bold:
        font += ("bold",)
    foreground = "#fffdf2" if piece.color == chess.WHITE else "#292521"
    return glyph, font, foreground


def draw_piece(canvas, x, y, piece, style, piece_images=None, square_size=SQ):
    if style in ("Tournament", "Staunty", "Merida"):
        if piece_images is None or style not in piece_images:
            raise ValueError(f"{style} piece images must be provided")
        image = piece_images[style][(piece.color, piece.piece_type, square_size)]
        return (canvas.create_image(x, y, image=image),)
    glyph, font, foreground = piece_appearance(piece, style, square_size)
    return (canvas.create_text(x, y, text=glyph, font=font, fill=foreground),)


def blend(base_hex, over_hex, alpha):
    """Mix over_hex on top of base_hex (fake transparency, tkinter has no alpha)."""
    b = [int(base_hex[i:i + 2], 16) for i in (1, 3, 5)]
    o = [int(over_hex[i:i + 2], 16) for i in (1, 3, 5)]
    return "#%02x%02x%02x" % tuple(round(b[i] * (1 - alpha) + o[i] * alpha) for i in range(3))


def square_xy(sq):
    return chess.square_file(sq) * SQ, (7 - chess.square_rank(sq)) * SQ


class ChessApp:
    def __init__(self, root):
        self.root = root
        root.title("Chess")
        root.resizable(False, False)
        self.board_theme = "Green"
        self.piece_style = "Staunty"
        self.engine_depth = DEPTH
        self.show_move_feedback = True
        self.player_move_context = None
        self.move_feedback = {}
        self.settings_window = None
        sound_directory = Path(__file__).with_name("sounds")
        standard_sounds = sound_directory / "standard"
        self.sound_files = {
            "move": standard_sounds / "Move.mp3",
            "capture": standard_sounds / "Capture.mp3",
            "check": standard_sounds / "Confirmation.mp3",
            "victory": standard_sounds / "GenericNotify.mp3",
            "defeat": standard_sounds / "Error.mp3",
            "draw": standard_sounds / "GenericNotify.mp3",
        }
        self.sound_enabled = os.name == "nt" and all(
            path.is_file() for path in self.sound_files.values()
        )
        self.piece_images = {"Tournament": {}, "Staunty": {}, "Merida": {}}
        self.board_textures = {}
        tournament_piece_directory = Path(__file__).with_name("tournament_pieces")
        piece_directories = {
            "Tournament": tournament_piece_directory,
            "Staunty": Path(__file__).with_name("staunty_pieces"),
            "Merida": Path(__file__).with_name("merida_pieces"),
        }
        for style, piece_directory in piece_directories.items():
            for color in (chess.WHITE, chess.BLACK):
                color_name = "white" if color == chess.WHITE else "black"
                for piece_type in chess.PIECE_TYPES:
                    piece_name = chess.piece_name(piece_type)
                    for size in (SQ, 28):
                        image_path = piece_directory / f"{color_name}_{piece_name}_{size}.png"
                        self.piece_images[style][(color, piece_type, size)] = tk.PhotoImage(
                            file=str(image_path)
                        )
        for theme_name, palette in BOARD_TEXTURES.items():
            for shade in ("light", "dark"):
                for size in (SQ, 28):
                    image_path = tournament_piece_directory / f"square_{palette}_{shade}_{size}.png"
                    self.board_textures[(theme_name, shade, size)] = tk.PhotoImage(
                        file=str(image_path)
                    )
        rating_icon_directory = Path(__file__).with_name("move_rating_icons")
        self.move_rating_icons = {
            rating: tk.PhotoImage(file=str(rating_icon_directory / filename))
            for rating, filename in MOVE_RATING_ICON_FILES.items()
        }

        self.board = chess.Board()
        self.selected = None
        self.last_move = None
        self.animating = False
        self.thinking = False
        self.token = 0              # bumped on new game / undo to cancel the bot
        self.engine_result = None
        self.engine_due = 0.0

        bot_header = tk.Frame(root, width=8 * SQ)
        bot_header.pack(fill="x")
        tk.Label(
            bot_header,
            text="KingJet  -  Bot",
            anchor="e",
            font=("Segoe UI", 13, "bold"),
        ).pack(side="right", padx=12, pady=(8, 4))

        self.canvas = tk.Canvas(root, width=8 * SQ, height=8 * SQ, highlightthickness=0)
        self.canvas.pack()
        self.canvas.bind("<Button-1>", self.on_click)

        bar = tk.Frame(root)
        bar.pack(fill="x", pady=4)
        tk.Button(bar, text="New game", command=self.new_game).pack(side="left", padx=4)
        tk.Button(bar, text="Undo", command=self.undo).pack(side="left", padx=4)
        tk.Button(bar, text="Settings", command=self.open_settings).pack(side="left", padx=4)
        self.status = tk.Label(bar, text="", anchor="e")
        self.status.pack(side="right", padx=8)

        self.draw()

    # ---- drawing ----
    def draw(self, hide=()):
        c = self.canvas
        c.delete("all")
        targets = set()
        if self.selected is not None:
            targets = {m.to_square for m in self.board.legal_moves if m.from_square == self.selected}
        theme = BOARD_THEMES[self.board_theme]

        for sq in chess.SQUARES:
            x, y = square_xy(sq)
            light = (chess.square_file(sq) + chess.square_rank(sq)) % 2 == 1
            piece = self.board.piece_at(sq)
            color = theme["light"] if light else theme["dark"]
            highlighted = False
            if self.last_move and sq in (self.last_move.from_square, self.last_move.to_square):
                color = theme["last_light"] if light else theme["last_dark"]
                highlighted = True
            if sq == self.selected:
                color = theme["selected_light"] if light else theme["selected_dark"]
                highlighted = True
            if (self.board.is_check() and piece
                    and piece.piece_type == chess.KING and piece.color == self.board.turn):
                color = CHECK
                highlighted = True
            texture = self.board_textures.get(
                (self.board_theme, "light" if light else "dark", SQ)
            )
            if texture is not None and not highlighted:
                c.create_image(x + SQ / 2, y + SQ / 2, image=texture)
            else:
                c.create_rectangle(x, y, x + SQ, y + SQ, fill=color, outline=color)

            gray = blend(color, INDICATOR, INDICATOR_ALPHA)
            if sq in targets and piece:
                # capture: gray ring around the piece (drawn behind it)
                c.create_oval(x + 4, y + 4, x + SQ - 4, y + SQ - 4, outline=gray, width=7)
            if piece and sq not in hide:
                self.create_piece(x + SQ / 2, y + SQ / 2, piece)
                feedback = self.move_feedback.get(piece.color)
                if (
                    self.show_move_feedback
                    and feedback is not None
                    and sq == feedback[1]
                    and feedback[0] in self.move_rating_icons
                ):
                    c.create_image(
                        x + SQ - 17,
                        y + 17,
                        image=self.move_rating_icons[feedback[0]],
                    )
            if sq in targets and not piece:
                # normal move: gray dot
                cx, cy = x + SQ / 2, y + SQ / 2
                c.create_oval(cx - 13, cy - 13, cx + 13, cy + 13, fill=gray, outline=gray)

        self.update_status()

    def create_piece(self, x, y, piece):
        return draw_piece(
            self.canvas, x, y, piece, self.piece_style, self.piece_images
        )

    def play_sound(self, sound):
        if not self.sound_enabled:
            return

        def play():
            try:
                play_mp3(self.sound_files[sound])
            except (OSError, RuntimeError) as error:
                message = str(error)
                self.root.after(
                    0,
                    lambda: self.status.config(text=f"Sound playback failed: {message}"),
                )

        threading.Thread(target=play, daemon=True).start()

    def open_settings(self):
        if self.settings_window is not None and self.settings_window.winfo_exists():
            self.settings_window.lift()
            return

        window = tk.Toplevel(self.root)
        self.settings_window = window
        window.title("Settings")
        window.resizable(False, False)
        window.transient(self.root)

        content = tk.Frame(window, padx=14, pady=14)
        content.pack()
        controls = tk.Frame(content)
        controls.pack(side="left", fill="y", padx=(0, 16))

        tk.Label(controls, text="Board").pack(anchor="w")
        board_choice = tk.StringVar(value=self.board_theme)
        tk.OptionMenu(controls, board_choice, *BOARD_THEMES).pack(fill="x")

        tk.Label(controls, text="Pieces").pack(anchor="w", pady=(10, 0))
        piece_choice = tk.StringVar(value=self.piece_style)
        tk.OptionMenu(controls, piece_choice, *PIECE_STYLE_NAMES).pack(fill="x")
        feedback_choice = tk.BooleanVar(value=self.show_move_feedback)
        tk.Checkbutton(
            controls,
            text="Show move ratings",
            variable=feedback_choice,
        ).pack(anchor="w", pady=(10, 0))
        depth_choice = tk.IntVar(value=self.engine_depth)
        depth_label = tk.StringVar()

        def update_depth_label(*_):
            depth_label.set(f"Bot strength: {depth_choice.get()} / 4")

        depth_choice.trace_add("write", update_depth_label)
        tk.Label(controls, textvariable=depth_label).pack(anchor="w", pady=(10, 0))
        tk.Scale(
            controls,
            from_=1,
            to=4,
            orient="horizontal",
            resolution=1,
            showvalue=False,
            variable=depth_choice,
            length=170,
        ).pack(fill="x")
        update_depth_label(depth_choice.get())
        sound_choice = tk.BooleanVar(value=self.sound_enabled)
        tk.Checkbutton(
            controls,
            text="Move sounds",
            variable=sound_choice,
            state="normal" if self.sound_enabled else "disabled",
        ).pack(anchor="w", pady=(10, 0))

        preview_panel = tk.Frame(content)
        preview_panel.pack(side="left")
        tk.Label(preview_panel, text="Preview").pack(anchor="w", pady=(0, 6))
        preview_size = 28
        preview = tk.Canvas(
            preview_panel,
            width=8 * preview_size,
            height=8 * preview_size,
            highlightthickness=0,
        )
        preview.pack()

        def close_settings():
            self.settings_window = None
            window.destroy()

        def refresh_preview(*_):
            preview.delete("all")
            theme = BOARD_THEMES[board_choice.get()]
            initial_board = chess.Board()
            for square in chess.SQUARES:
                col = chess.square_file(square)
                row = 7 - chess.square_rank(square)
                x, y = col * preview_size, row * preview_size
                light = (col + chess.square_rank(square)) % 2 == 1
                color = theme["light"] if light else theme["dark"]
                texture = self.board_textures.get(
                    (board_choice.get(), "light" if light else "dark", preview_size)
                )
                if texture is not None:
                    preview.create_image(
                        x + preview_size / 2, y + preview_size / 2, image=texture
                    )
                else:
                    preview.create_rectangle(
                        x, y, x + preview_size, y + preview_size, fill=color, outline=color
                    )
                piece = initial_board.piece_at(square)
                if piece:
                    draw_piece(
                        preview,
                        x + preview_size / 2,
                        y + preview_size / 2,
                        piece,
                        piece_choice.get(),
                        self.piece_images,
                        preview_size,
                    )

        board_choice.trace_add("write", refresh_preview)
        piece_choice.trace_add("write", refresh_preview)
        refresh_preview()

        def apply_settings():
            self.board_theme = board_choice.get()
            self.piece_style = piece_choice.get()
            self.engine_depth = depth_choice.get()
            self.show_move_feedback = feedback_choice.get()
            if not self.show_move_feedback:
                self.move_feedback.clear()
            self.sound_enabled = (
                sound_choice.get()
                and os.name == "nt"
                and all(path.is_file() for path in self.sound_files.values())
            )
            if not self.animating:
                self.draw()
            close_settings()

        tk.Button(controls, text="Apply", command=apply_settings).pack(
            fill="x", pady=(14, 0)
        )
        window.protocol("WM_DELETE_WINDOW", close_settings)
        window.grab_set()

    def update_status(self):
        b = self.board
        if b.is_checkmate():
            text = "Checkmate - " + ("Black" if b.turn == chess.WHITE else "White") + " wins"
        elif b.is_game_over():
            text = "Draw (" + b.result() + ")"
        elif self.thinking or b.turn == chess.BLACK:
            text = "Bot is thinking..."
        else:
            text = "Your move (White)" + (" - check!" if b.is_check() else "")
        self.status.config(text=text)

    # ---- sliding animation ----
    def make_move(self, move, done):
        """Slide the piece(s) for `move`, then play it on the board and call done()."""
        board = self.board
        slides = [(board.piece_at(move.from_square), move.from_square, move.to_square)]
        if board.is_castling(move):
            rank = chess.square_rank(move.from_square)
            if board.is_kingside_castling(move):
                rook_from, rook_to = chess.square(7, rank), chess.square(5, rank)
            else:
                rook_from, rook_to = chess.square(0, rank), chess.square(3, rank)
            slides.append((board.piece_at(rook_from), rook_from, rook_to))

        self.animating = True
        self.draw(hide={s[1] for s in slides})
        sprites = []
        for piece, f, t in slides:
            fx, fy = square_xy(f)
            tx, ty = square_xy(t)
            items = self.create_piece(fx + SQ / 2, fy + SQ / 2, piece)
            sprites.append([items, fx, fy, tx, ty, fx + SQ / 2, fy + SQ / 2])
        start = time.time()

        def step():
            t = min(1.0, (time.time() - start) * 1000 / SLIDE_MS)
            e = 1 - (1 - t) ** 3  # ease-out
            for sprite in sprites:
                items, fx, fy, tx, ty, previous_x, previous_y = sprite
                x = fx + (tx - fx) * e + SQ / 2
                y = fy + (ty - fy) * e + SQ / 2
                for item in items:
                    self.canvas.move(item, x - previous_x, y - previous_y)
                sprite[5], sprite[6] = x, y
            if t < 1.0:
                self.root.after(FRAME_MS, step)
            else:
                was_capture = board.is_capture(move)
                self.board.push(move)
                self.last_move = move
                self.animating = False
                if self.board.is_game_over():
                    outcome = self.board.outcome()
                    if outcome and outcome.winner is not None:
                        sound = "victory" if outcome.winner == chess.WHITE else "defeat"
                    else:
                        sound = "draw"
                elif self.board.is_check():
                    sound = "check"
                elif was_capture:
                    sound = "capture"
                else:
                    sound = "move"
                self.play_sound(sound)
                self.draw()
                done()

        step()

    # ---- player ----
    def on_click(self, event):
        if (self.animating or self.thinking or self.board.is_game_over()
                or self.board.turn != chess.WHITE):
            return
        col, row = event.x // SQ, event.y // SQ
        if not (0 <= col < 8 and 0 <= row < 8):
            return
        sq = chess.square(col, 7 - row)
        piece = self.board.piece_at(sq)

        if self.selected is None:
            if piece and piece.color == chess.WHITE:
                self.selected = sq
        else:
            move = chess.Move(self.selected, sq)
            moving = self.board.piece_at(self.selected)
            if moving and moving.piece_type == chess.PAWN and chess.square_rank(sq) == 7:
                move = chess.Move(self.selected, sq, promotion=chess.QUEEN)  # auto-queen

            if move in self.board.legal_moves:
                self.selected = None
                self.player_move_context = (self.board.copy(), move)
                self.move_feedback.pop(chess.WHITE, None)
                self.engine_due = time.time() + BOT_DELAY_MS / 1000  # bot moves 1s from now
                self.make_move(move, self.after_player_move)
                return
            elif piece and piece.color == chess.WHITE:
                self.selected = sq  # switch to another of your pieces
            else:
                self.selected = None
        self.draw()

    # ---- bot ----
    def after_player_move(self):
        game_over = self.board.is_game_over()
        self.thinking = True
        self.update_status()
        self.token += 1
        token = self.token
        self.engine_result = None
        board_copy = self.board.copy()
        search_depth = self.engine_depth
        player_move_context = self.player_move_context
        self.player_move_context = None
        rate_player_move = self.show_move_feedback

        def work():
            rating = ""
            rating_square = None
            if rate_player_move and player_move_context is not None:
                position, player_move = player_move_context
                rating = classify_move(position, player_move, min(search_depth, 2))
                rating_square = player_move.to_square
            move = None if game_over else best_move(board_copy, search_depth)
            bot_rating = ""
            bot_rating_square = None
            if rate_player_move and move is not None:
                bot_rating = classify_move(board_copy, move, min(search_depth, 2))
                bot_rating_square = move.to_square
            self.engine_result = (
                token,
                move,
                rating,
                rating_square,
                bot_rating,
                bot_rating_square,
            )

        threading.Thread(target=work, daemon=True).start()  # search runs in the background
        self.poll_engine(token)

    def poll_engine(self, token):
        if token != self.token or not self.thinking:
            return
        res = self.engine_result
        if res and res[0] == token and time.time() >= self.engine_due:
            self.engine_result = None
            move = res[1]
            if self.show_move_feedback:
                if res[2] and res[3] is not None:
                    self.move_feedback[chess.WHITE] = (res[2], res[3])
                if res[4] and res[5] is not None:
                    self.move_feedback[chess.BLACK] = (res[4], res[5])
            if move is None:
                self.thinking = False
                self.draw()
                return
            self.make_move(move, self.after_bot_move)
        else:
            self.root.after(30, self.poll_engine, token)

    def after_bot_move(self):
        self.thinking = False
        self.draw()

    # ---- buttons ----
    def new_game(self):
        if self.animating:
            return
        self.token += 1
        self.thinking = False
        self.engine_result = None
        self.board = chess.Board()
        self.selected = None
        self.last_move = None
        self.player_move_context = None
        self.move_feedback.clear()
        self.draw()

    def undo(self):
        if self.animating:
            return
        if self.thinking:           # bot hasn't moved yet: only take back your move
            self.token += 1
            self.thinking = False
            self.engine_result = None
            count = 1
        else:
            count = 2
        for _ in range(count):
            if self.board.move_stack:
                self.board.pop()
        self.last_move = self.board.peek() if self.board.move_stack else None
        self.player_move_context = None
        self.move_feedback.clear()
        self.selected = None
        self.draw()


# Piece images (80x80 PNG, base64) so the script is one single file
PIECE_DATA = {
    "br": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAGWklEQVR42u2cXWgcVRTH/+fOzGbTzSbZSmKwxGBThZYqpSCUSpv6"
        "EEVBq2LwQVBSAulLfRDsg4piEVr8wECVIkh9UER8KimC+CAU7ItUYvJSolTRNrRVm0AW92Nm7j0+7J1msjWbze5kdmLvgWFgd++d"
        "M797zrnnfi3ByFqFADCAHID9wvBoTgxAA9AANAANQCMGoAG4QcWOOMFcSbjJ8vXWEYUesQMkABYAVeM3FgC/ifLB70ST9VgAZJQg"
        "owDINV4qENVk+ajqUUmyQKEVugvAMQB36JegqpciAL8CeBVAOTSWDO5ZAG8D6K/hgoHFXATwpgZVXU83gBMA7lxBDwCYA/AagMVQ"
        "uZaJpe9jWpHVrkc0dEffbX1/rM7ywbW7qnxQ3wt1ln+8yQ40aJgcgIN2k64LAJu1RcgQ1OrfCQBd2mJVlTtldHlVx0sRgI4V6smu"
        "Uk/weW/SOhGp66EaAAnAfdp6UqGX8QBs1+VVnVbxAIB/tOUFZVwA96xSj1qlE2ppL1zP92/oOFgdm5w1utT7oRjYSD2UNID1Skpf"
        "SalnwwHkiKyC47KuOAFKy7IQk+s0Wg9LKWViRyJSSoVki5VUC/Rs257eu3fv/evQwNGYLBGY2T1//vzFVrh5Db0IlmU9c+jQoQFm"
        "nuKKSKUUJ+ViZqn1+gbAIIAnk5JIg5kpk8lMnz59enhubm52aGhoZz6fJ6LENDKUUujo6JBnz569DGBfLpf7bmFhoeXDuOrWuBfA"
        "D1opqZNWbuGlQnoEsy/fAtgSQYe2zAIpouAs9+zZ0z41NXVKSvkiAPi+z7Ztk44/ccY6AIDjOPA8rxLobfuDcrn8sv5ONDkrs2xh"
        "PSpfu6lUW1vbkXK5/M7hw4fTo6OjKBQKEELEGZjhOE5xfHz855mZme1CiDGl1Gchy+EIvO4mwKjyQKUrFp7nnQTgXr9+/ZlsNvsQ"
        "EWViy9SZZTabtTzPe3dmZqbkOM5lz/M+x9JEayLi3mppkQCwDcDfoVmTOOOfBFAioqt6pshCtGs/y2Jg1L4VBPB2IUS6VTmXEKKN"
        "mSWATRro+j1r/bIH1bKRSejR666DWdY0AA1AA9AANGIAGoAGoAFoxAA0AA1AA9CIAWgAGoC3j6zn5iJFRNyKNWJmVsysNjJABpBl"
        "ZuK41jRv9awMYlhEWg+AlE6nu0ul0ifDw8PO0NDQaD6fl0RkxWB5MpPJWJOTkycvXLjQkc1mO/P5/LX1fGbU/mURkbQs6/WtW7fO"
        "z87OPgvg4VKpxHHs92BmlU6nBYCvMpnMj67r5n3fP4Wl8yFRMYt8Yf1mh5ROp7eUSqUZAM7IyEgm2B0QlwS7E86cOVMgor+YeTcq"
        "xxrCG9MTCTBQfgLA0/39/XffuHFDEVErenrO5XJ05cqV3wF8DOA4ojsXEvnOBAFAdXV15RYXF9/q7e3tPnfu3C9Syn4pJeLshZk5"
        "aER2HAeu6/504MCBXfl8/piU8gSAAiI+YBPZLv1CofAKMx/ZsWNHYX5+fpN23VbtcxNEBCnlwYGBgdL09HTatu0/fd//UDd4ZIvt"
        "FKFJfwlgBAC1t7cjnU6TUgotygMhhEChUEC5XA7i3kcAXkLEu7OiTGN83fKyWCxaxWIxESMFImJmrnVaNDF5IIXjUFIklMdTkgCK"
        "kEIEgKkiaM3Ao3ZmoPUibYlh3bnZ1KZRgOo/WtrlpNFb0o1ROWorEfFurUYBbgOwE4BjWZYSQrT19fVZExMTCz09PZvjGnms2spK"
        "cSaTsS5dunTt6NGjm+fn559TSkkpJWmgUwAuN5Pa2A2W+RqV05dgZnieh87OTgwODqK7uxu+7ydip75SilKpFAD02bY95nneWNV2"
        "4+8B7IsrjQlaqQfAbwDSWH4yXKRSKXIcJ1FxkIhQLpfh+3443gVHX6+icnbEXYMVNp3GBIpYVQDhui5c101iGARV8hkrBKHZfLBh"
        "FxYrWW6S0pca6Uy1NVHcAHklU09oJ7zau7TMAhVu/XeMjSIqquS6EYAF1P//BkkVERp++s1Yo71GcycAeQDjAA5i6YDNRnNb0uC+"
        "0Il1w3kgwUhLZmP+T+vJyRgL365idiYYgAagAWgAGmko/UulLGEANjgX0NnZSa4riwRgv2GyNoCWZbVJKf+Y/PQ9YeuM2kidkkpZ"
        "BECOPf/UriceffD4vzgBT/9AlHEOAAAAAElFTkSuQmCC"
    ),
    "bn": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAM1klEQVR42u2cf2wcZXrHP+/MeNfr9foHiZPYcWKb64GTEF9Qelx6"
        "nHAqlJO4ICi04OsFtSlSS6FVJVSVUjW6oIOW0oIOUul0f9y13Im2FmkuqsrpAk6gNA2J4hYFW7bZ2PEPbNaxje3ENrb3x8zTP3Ze"
        "MxiH7Dq79gb2kV7J3hnbM9/5Pt/nx/uMIW95y1ve8pa3vK2OmTl2PYa78gC6QJiASuNaHEDc71We358F9EqmwdoI3AGEvswgaqDu"
        "BX4KPAlUXQFE5fnsd4ELLgPPAvUpAP+FBe9bQNwFQ4Ae4LYlZEN//Veec/XP/TJNCfhCBaVHXRDmgYT79RjwTc95+tzvuscT7nIA"
        "2/269svmyhqU33eBiHvAEaAPqPGc/xUg4h6zPSzUweS33N/pc9mtcg3MbOnLpUU3anoY9TxQDBQCTwOVLnjea9GRuMg9FvOAKoD1"
        "RdVGzcDb3Rt2Ft244wLZCbS5Lu49vpiBbcAPgb82TfPetWvXVr711luWUuq6zh1JIR0pd0Hyum8mVgQ4CvwgFAp9RymFB8xVCTjZ"
        "SKQtYBaoc4OGLMEQzcyraZpjGIYjIvZDDz1kPPfcc0fr6ureO3PmzFfm5ua2A48A26qrqwemp6fHPfck1zMDtdi/fi0MVEoJIIZh"
        "iFJKmpubZWJiQsbHx+XSpUu/mJmZ+dGDDz74e2vWrDkE/A/wd9XV1RtdRl63bq0Z3QjMLaGBKa+iQr9YliWAlJSWyLHXj8nY2JjT"
        "399vj46OysjIiIyOjo5NTEx0v/nmmz8oKyv7CdAK7Fvk1tdVEm0AfuAdnZoYhiF6aValykB9vmmasnHjRrnvvvvklVdekY6OjsTY"
        "2Fi8r69Penp6ZHJyUmzbPt3c3PyTdevWnQMOV1RUbLieQPSWZD/U4KUDWDpr+/bt8sQTT8i5c+ec4eFhJxwOxwcGBmR0dNTp7u4e"
        "a2ho+F+gLRAIfN2jy9eF6x7QuqeUcgCprKyUxx9/XA4cOCDr16//lL6ls7xM1p9t3rxZXnjhBRkaGpL+/n67s7NTBgcHZWhoaHL/"
        "/v0CXA4EAvfnOhM1835T53CGYTiAbN26VU6dOiWjo6Ny+fJlefbZZ5cN4GIwTdNc+P6uu+6SM2fOSCQSkc7OTqevr08ikYjd1NQk"
        "QLSwsHBfLjNRuaXWWQ/7pKioSI4cOSIjIyPS0dEhAwMDcvjw4YwA6NVJzcgbb7xRjh8/rkGU3t5e6evrs/fs2SPAnM/nuysbTDQy"
        "8PPiNg++7gYNU0TYu3cvt99+O5OTk1iWhd/vp62tLYm4yky+KyI4joNlWfT29rJv3z7a29spLy9nfn4ewzCMF1980dmyZUthLBZ7"
        "2efzbV2ibFxV11Vur28EcJRStlJKSktL5dixYzI0NCThcFh6enqkt7dXdu7cuRBVMx1Y9O+sqqqSkydPytDQkHR2dsrw8LAcPXo0"
        "EQgExLKst2pqagpzpU2mn+KPtevqm9i1a5cMDQ3J+fPnpaurSy5evCjPP//8Z9KTTC/tzvX19dLe3i59fX3S1dUlo6Oj8uSTTyYA"
        "sSzrQC40avUf3+WWbQ7gaAB3794tExMT0tHRIcPDw9La2ioVFRVZBU8vnXw3NTXJyMiIhMNhuXDhgnR3dzvbtm2zgUvBYPAWl4Hm"
        "agJoAi3eck0ny5WVldLS0iLj4+Ny7NgxufXWWzMaPFINLIcOHZKLFy9KV1eXRCIRaW5uTvh8PlFK/etqslD/0d/xtKc+cyM33HCD"
        "7N69W0Kh0IqB53VlpZRUV1dLW1ub9PX1STgclkgkInv37nWAeCAQ2LUa+aGuOMqAc1dqFiwGy5v8riSIgDzyyCMLLPzwww/lyJEj"
        "CdM0RSn1Hw888IDpCYYryr4/87Thnc9zpZVk3lK1dDAYlDfeeEM++OADOX/+vPT39zuNjY02EC0pKbltURma1X6gfkprgJ8BJVfT"
        "EZHVbcuZpkk0GiUWi3H33XczOztLKBRSBQUFzmuvvVYQi8XmgV+595b1i9Vg/20WOs1Z1cKSkhI5ceKEDA0NSXd3t3R2djpVVVUC"
        "9IdCoTWLCJKVSsRwXbUGeNjTTc5pcxwHpRRTU1McP34c0zSxbZuysjLuueceAWri8fh3riWYpOP7AvwJsP4KbfqcNBFBKcWrr77K"
        "7OwsSikMw1B33nmn7ff7iUaje0VEuXqusgGgZl8d8EcueNfVRreIMDAwwLvvvkswGGRqaoodO3aYdXV1iMht9fX1xcvVwFQA1GD9"
        "MVDqgplN9onnZpxMgGeaJolEghMnThAIBIjH45SWlqqGhgYBavv7+7+5XB00UgDPBjYA+72uu2hLMdPgKeAFYNTz+TVbe3s7ExMT"
        "+Hw+YrEYe/bscQAVi8W+nS0AtbB+D1jn5ldKP1mtL5nSfM8DOkBysqs8k8HkvffeY3h4GL/fTyKRoKGhgVAohIh8q7Gx0VoO440U"
        "2FdMcvRMvLldRUUF5eXlmcr1tCwYwPeBvwG2ktygylggmZmZobu7e8Gly8rK1LZt2wBq3n///U3LCY5GCs3SHcDXXLc1gsEgL730"
        "EqdPn+bUqVM89thj19ok1Q3Oy26K9LT78NZ7wM0Yzc+ePYthGMTjccrKytRNN90kwJpoNLppOQ0G4yp6BHA3UGCapiMi3HHHHTQ1"
        "NSEihEIhHn30UWpraxERDMNIV+9sVyYGgfuBfwYKXMB2ZSqQeC0cDqOU0sFF1dbW2oA1Ozu7czl6a6UA4HavwJaVlRGNRonH4wsn"
        "FhcXL9dlTeCMG6DCLnhx4AaSo74Z75ZEIhGmp6cXyrz6+npVUFBALBbb4QLrZJqBlhZigHfeeYepqSnWrl3LunXrCIfDXLhwYeGp"
        "puGyCeDvgT0ueKZ7DJITrjWZdF99bR999BEDAwMUFhYyPz/PzTffrEpLSyE5n51RBuoCe9q9AFFKMTAwwMMPP8zOnTuJx+O0tLQw"
        "NzeXCoB6bM0EPgD+FPhPz4O0PXsV381k+uK1yclJIpEIt9xyC/Pz85SXl6tAIADw1S1btvg6OztjmQJQ2+XF0ay1tZXW1tZ0Oi+O"
        "p4V+GPgLYIBPXm1wPAz8BnBfpisenVDbts3Y2BiWZS18tmnTJgYHBzcMDg7Wud6QcnfGSOFY6+ILMQzjUyuFYKGbls8ATR7wbA9Q"
        "4mrgcySnVzNeb+tMYXJyciGPNU1TVVdXAxREo9FfSzcSp8LA0yRHbAv0zWo9TDHSAkwAfw687Glg2osS9gTwlyQnu7JSLnp1MB6P"
        "68YCdXV1DmAopaoymUhrtwsDb3sS6+XUtH/ogmctkZpYLnj3AgeX2xVJx0ZGRhayCMMw2Lx5swZ4bbol3dWisCI5x/x9Phnutj0r"
        "8Tmg6mj7DPALl8GJRdqimfcN4Odu5ZG1SXzNwPHxceLx+IL8BINBxz2+OZMAell4BvgDku96mJ5lLZGn6ZdlLOAVl1U6bVlcZ9vA"
        "V4F/I7lFkO1ODwDT09PYtr2giW4Uxrbt9Z6HrzIBoDcI/AzY6UbQf3RTkNfdqAqfnnsuAP7LbcAudmcveJXAq26vMevgaQZ+/PHH"
        "C3mtbdsUFxcry7JwHKf04MGDRqarn1TAPukBKQEcAdZe4ef09xtIzjav2P6K3iGsqamRjo4O6enpkcHBQWlpabHd/ev/q6ioKE7H"
        "jdOZl3P49Bag1qoEsM+tKGySbyO97TnHWaK7XQH8O8n3SWxWeHN7ampqwYUdxyEQCFBUVMT09HRobm4uAMykmgumO3AoSwQN5VYW"
        "P12iiy1LgFcM/MtqgKddeHZ2dgFAEaGgoAC/3w/gKywstGZmZjJaiaQCqpeZsoSGKI/2vexh66oN93grJ8MwME0TwHIcJy0dztTI"
        "q1wlR9Su/A/Ab7tuv6rjthpAt7JSbkrjcxwnretaia1J7bp73GrEIQcGvnVdr0tTy7IALBExcw1AXeM+43HlVd8W9XbQTdPULuzP"
        "NQbq99buJ/nGukOObchrBroABhzH8ecKgDoNMEnu6pGtBPVaGSgiSpKiqETESMdLsg2gQ3Jz6DdWUDKu7hauy2oddBxHEomEcoGV"
        "XGIgJLcnK3LBfTXrgsEghmEsABiPx717PLJEDpv1NObz7NfTuaCVML/fj1Laa8G2bbFtWy1Rs68qgPpCqsgxsyyLgoICZVmWTl9U"
        "IpHQXZicAVBbkE9GgXPCDMMQ27Y/1l3pWCwmsVisiBybOtMJ6T+RY5OrSqm3RcQnIn4R8TU2Nm5QSn3oHq9NJz5kk4GacYeAKBDI"
        "FR0UkXGl1H5PquUj2ds8S3JKQqXqMV/m/5BmLtLrZUnMSgCocvBBLRVtjVxL9vOWt7zlLW95y9uVzN1Dztsyk/H8fxm+VvBee/p7"
        "NXkKpg3eQeOpp55S86P/fVP9jq+d/H+O6F2TYnUDkgAAAABJRU5ErkJggg=="
    ),
    "bb": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAJcUlEQVR42u2cXWxcRxXHfzN3vfamsbesF4FDSEswLlWFLGyJh9Iq"
        "fARiigSlL7yQCKUWEhItoFApgvBAJArigYpKQSHAQ6Qo8IAiFYEIdVQhQqhIcRQIlWjsOLhSnK1tvHYSrzfee2d4uDP2ePF+2tf1"
        "xnuk0d69ez/mnvmfc/7nzNyFpjSlKU3ZuiI2aZ+k2VbmuwC0+d6UMiIr/O41EVi+LxqIA08DnwK6gWngNeAEcM0ouYnEEsjrBf5s"
        "FFncMsBXNrHreVuVJ4AEcMUoaxEInOY7ihyo0ty3HPpeNAoqlECgb5Q5CuwsCjZbXlqBSQdxukSzyn1yswSVt3sErS/rMn2RFfyb"
        "MAFkR6PQhqhFm8//Gr/n7it1vDSRualAB1W3gfEqlacNnWlKkR/7mlFOKR9o918wEVs06cwyAluAGHDK+LhiJSrzOQ58wJzjNU14"
        "GUUFo8ALwKyTlVjTtd/PAzkHkd5WRp47eAPAxTL0xUXhW8Bho3DrAracKVvk3A8cX8XP6Qp+0PrCjxQheUv4O6u8x4C/F2Uauoqm"
        "nGPngWeda8qtgrxnDO8rl7rpGtD4W6DzXleiVd63qzVZKaUWQlSLxj8BqXtVidbhP+eYq6oTeeVy5PNA+71W8rJo+JKDuorKE0Lo"
        "3bt36/b29lqV+BvCouw9EZ2t8t4HZEuQ5BXN8zwN6IMHD+qxsTF96tSppX1VNOtXv7FR1ZoofYVwzPcFQ1lUpXtqHfLn/v5+0uk0"
        "vb29dHV1hRcUoho/q4HvAQ+ZwZKNrEAFPAV8vlLm4HnekoKEECilyOfzLC4u0tLSghACIcSK40o8jwI6gOdNihipP4xSgdqg7zvV"
        "PEQQBGitUUqhtSYIAjwv1Hc+n1/6zR5XAYUB8AWgj+Wp0UijYxTX9YFPAo+UM10hBFpr9u/fT19fH77vEwQBvb295HI5EokER44c"
        "YX5+Hs/zuHXrFsePH2dycnKFyZewgK8Cf2vEYGKVdaIcWbYcb9euXXpsbExns1mdyWT01NSUHh8f1yMjI/ratWs6k8noyclJPTEx"
        "oQuFgh4cHFziiRVI9gRhtTsyM45F6PvagMfLRUOtNUIIstksIyMjdHd3s7i4uOQTPc9Da83s7Cxaa7TW5PN5xsfHq+mDBt5lzPj3"
        "pg9+VJFyva+pgfcDI5XuYU04mUzS3d2NEIJCocChQ4fYt28fN2/e5PDhw2QyGVpaWpienub69etL55WRggkiR4DvO26lIRBoFVhx"
        "gCwK5+bmGB4eXto/MzOD53kEQcDly5fJZDKr0p0qwPGAjVONZMIQzt1SLfezNMUiKxaLEQThM2/btg0p5RK9qUJ5bj+6WFmgbRga"
        "s60mzmNoCoBSioWFBdLpNC0tLczMzKCUqkV5rgITUbqsWIQKzNbTaaugkydPopRieHiY2dnZanzeajwUwikCXbSvIShM3zpWW+pp"
        "Ni/+QZR5cRQmbEd5hHD+oq6RF0IgpUTKurtoFfaPKHlgVAoUhOX2C04goVZTtn6vDrGBaxa4VG8fNkMB9Umqmyxa72ar1L+OOliK"
        "iH1hq8kCPu5WYyxdWTfImyzFsQBliPRHDQIbclWrG0zyVF66tt7B44dRBo+NQKBbWnoa+IXdGY/H6e7uJhaL1UpN/n+UpOTGjRtM"
        "T69YsPUS8MWiIkZDlbNw0icJ/BLISSlfUEqlDxw4II8ePSpsgKjXnJVStLW1MTQ0xODgoMrlcgUhxCmt9deBu1FmIBuRibgRMQb8"
        "qq2t7Qkgl0ql6Ojo0BZBbhpXa4vFYnR1dSnP8yTwI2CQcP1M5MrbCBO29xAh0MQZ4HPJZFLt3btXplIpgiBYU0DRWnP+/Hl99epV"
        "gClgH3CZe+h1CIvy71LDtCb1r1QYJpzAkhthYWIDlKeAHiHEJSFEwiBRSCnXHEDceqLxpz4QU0odAn7sBLGGFUshfsra1sFU2yyy"
        "p5wqTKQgiUWM7iCZTN4/Nzf3wc7Ozjd37ty50/d9LdaTRS/7Qu15HvPz89mxsbE7UsqPBUHwB2MFQSOasAB0f39/enh4uHNoaKi7"
        "p6fnd9lstqC1bongfn4ymYxls9mX+vv7D6bT6Qenp6cvRR2No0SgBhgdHW0fGBj4z549e57zfZ9EIiEjACBaaxmPx9WOHTs+pLVO"
        "pVKpqYGBgdazZ89GygejVKAE1Nzc3FPnzp17/NixY581zj6S1EoIIYMgUOl0evfp06d/ns1mx2dmZp41hLqhA8gzRTnqRuXCf3Fo"
        "jGhEE7ZyGbDLNHTUUVEIoc3yj9edLMhvRATaDKQD+KtTp1vvxZUukbY0KQ98mk30Pslao/w7TTVmtddXlaif8wXOoNj9FwkXsG9U"
        "rh9d7msewF0p+mXg1YgQOAr8hOUlvjFWvgEqokRIPedJl64429XQhYcMSh6Led6jHR339dy+ndMF36/YHyklba1xlVvI3wD+aQbk"
        "FZMDL1Y5uCu46lqKDrE6z/HLsPsYcB+wnXByfRvhQqNWs+0Bd6WU80qp19u3J+K7H3hPzxujb1K445ec/xUCtEbHPE90ppLBwkT+"
        "otZcIfwvhQ7gE+baOUNd8sAC4eRWDrhj9ukSfQ7q4Yq1INAtDyWBhwnXnewxn2mzP0a4yDtOuLjHvkjoOWYVJXkPnAEumLZomt2e"
        "IJyxe4Xw9Yg3VnnGSEpSceCbhHOta036ffMwvpSipvPNukLfUdBafOod4GfGrUDlt+brVt4O4OWiKGpHulRTZdp6V2HKtVL9c6P3"
        "AvCtVZ57XYLMu1n+SxKfjZ/njboE5pbZThifvW7oiwNnqkzHakFcObT4Rb7LrwPRtSLffW3sVcJ3W9ZEfyyD7zWdXyxCnnIeVDUg"
        "6kr13Ubq54v0UDONsetLxoA/Ap9xEGIv7K0SBVXRcS6hdSUo8k92+zrwL5P+zZnzPkw4Qf+woULSuX8xWXevbxEli1pxiudSslZz"
        "3zOr8NyaaYy7WPtFwpdmYs5NXzPtiimj33L4V84c12E4YaKowznD0eZNJJw3/O1uGSoRd/jkdsM37XbcOa5grnnb9Mdy0YQ5J0W4"
        "BLkPeNRQMCtXTDB5uZo6oqgykNiLPAK815jzW4R/P5KPKEPyiqwhqinKBw3DeAfh/9H82yCwqiKsqOGBSl2sxXm44rTOvYdY5bfV"
        "TETX0OdS28XXX+04USb7qJpQixpR4UYlTcTrTja48OGivZGfqSlNaUpTmtKUpjSlKU3Z/PI/otDfjrdAwVgAAAAASUVORK5CYII="
    ),
    "bq": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAS9ElEQVR42u1ceXBcRX7++h1zaUbS6NZIo7ElGwvbmFg+EZs4hrBx"
        "8NrmMLCEikNqE5ziSqVqoQK1FElt2GKTTUJS4VrCVkgFCOAsWxQh3ipgHbyYGEeGlW2wJdu6LcnSjI7R3PNe54/pHrcf782hwzK1"
        "7qpXM2/U3a/769/5dT8BV8qVcqVcKb++hXyNxkYvx0HKlyl4kglo8q8jgJJwkSLa6Ox7GQAPu08VoTWEzU0SFuNrZxoki99JAZJ3"
        "HYDXABwD0A3gEIC/AlBeAIjS10zbctqupQyMbwBYkcf28onvBBBh6mu8DjKptOqD/1YK4DcAbAHQJgD/tQGvDMA/ADgHIM0mPw7g"
        "VQANJgDw75UATrP6SQAau9LsngL4WwuJ4gtwM4BOYRGiAL4AcHcOzbisALQB+JmFBFEAhwF4DcAp7PM+VkczacfBHALQaACNf24H"
        "EBPa6IY+7smj5osa8nCJ+DYbbIpJjs4ujf1GATxuaMMBfIrVTZsAyMGIMfXk7fm4PAB+JTxbFy5+f5pJeb75FBzeSQWAJrOLsvqy"
        "yQOI4Dl3G0AlguoQ1s+tABysjdhXsoDBc3U2TnYDgDWsT0V4LmH3FEALs8e57DCfq+jJZw2gqDpEkCRq0pYy9a3PY+QJgDpmJ6kB"
        "/ENC7GcMnLkEngIwYGgHAE0FBNs6gGaL8YnzE+eu58JJySF5fHJ7AGwDsBzADLNhLzF1IMKgCVOVoDBZq0WZBDAt3PNnfQDgvwB8"
        "yyCdVFD3fwQQZveaUGe0QI0bNVkgPo9bANzOIoY4Mwn/BuCIIT4tKIazAfiJhSMYAPCbBinmi3G/wQ6J7bgN/HsTT8pVvBrATwW7"
        "x/sIAnjIRHr488sB9Fk4IX4/YRIFEMH+ms11GsCuYpwPn9QjBmeQNoQTXUwVYbA3XgC/NAGAf54FsMwipBAn9YgwiT4Aa3MExLyf"
        "vSZORwTzzw31eV93CHVTJnOdZFKZNwziIHhY7GTlEflv3zFIHwegFsA+A3g6gE8ArMzj6VSDJOtM+mrzpGa8vz9mExbtdQjAwzni"
        "z1/kmCvXmr8sJKPhg1vL7IxZLCWq549NOhUHuBXAcaHdjwoYBB/Dm6xNQrBPudSImwC3EIxTAC9YOA7+vRrA+Rxz5aHYfxfrhYuh"
        "j6jhOw8HfsFyWV7uBlBjMP5mnrCEqbk40WvySC7//RYGWJrdv8fMhi2PY8tXUoUAyL3haQAjwqpYrfanFv3oApA8rNEA+ADclEMK"
        "RROw3BAubSwgRKEA7jKEOD5DtGCc6xgzV1ZA8mjgc7NxmwEoMfV9WbCJaWFAPC46x0IOIsROZg93CgACwJ1CGytpuoapIhXqrGS2"
        "2aydxOquZGZDLPYcEsbn/4oJDjyDUZn3fr2YlI2wB/+zRUo1IwxUyjO4XxmC0qjgSCSLCOBJwQlwyZoCcK2F9PL77wt2K2nwvEqO"
        "qEMS5moMgcYYQ2RqPiQLe8CN94MA/gDAfmbL+Oo7WeSfyyZRk4Fzibw9T9u1BrXTGUXVYuEMNJYa7jTpy1ZAzqsKBAWYBn7GJPN3"
        "AbwjSDmKlUTRo4o83QSAq/JIIQHwpSElpIxuKjE8g38vY0ZflAYeSvzQIgAHm2haaMMl8Hs5JJC3/a6hzQcC75jT2ebzwlSIyzoY"
        "aDyhLwfwtIEwgAlNJVnYqusMYPC/LWWhhdgP72OVif0kAgskG1JLMa6kFlsHKxk7JP79ODMZSr4UrpDUJMUGNg3ghNBOY6zK7+dw"
        "CKqJvdLZb3cbvDxvv4w5EN1kQVYJTkkchx/A71mYBTWH6hIAf8eyJ10Y66dCHX0ubIzRnh0zhAAUwA+EQFUyISski2fuYiGGbgg7"
        "Ngpe2yhlSwBcbbLv8i0W+mgWY4CF9P0pI0o0IctJAOgRNBDzASARPKpxEI3M++kmq6+YSCAHq1JI0mWh/SoLT8sns8bgPMBiP+RJ"
        "DamJ1D5lIrVBRplhPgHkHR1lNI8sUEwaU8c7TSRAzePp72QgcyBKBACJierDADBlEtueIzhXTQRBYrSYV4hrqWD/goXSV8UCOMqo"
        "LBiMNWGqXGXg7uQ87Ml1jJ6nQrAcyBPibDCAfgcDSc8jgaKk383st0iW8jGcKCZUKWZzhTAv3GehEi0A/sZgO5Q8Oa/doH7X5FAd"
        "3k9AsHeVDIh8MR6EjMovjNNsbMeK2RcpRgK5uv5fDqO8B5ltRS2HDTROcDeTXABYncPzcafVwOwuYXl1cx7aXTVoyl8z50UNjLfE"
        "4sCOYsiUYiTQKOKSCRiyYFt4OihZrCgHfQkyG+AAsDmPBGpsUdazOt+2IArMvHCaqfsek7CLgzkIYHihATwleExqAsgyZI5hUIs4"
        "0KzPWxnN1VBAZsNjxQCAGwqYhx0XNrJ+IIBFTMbRx8hXshA2UBe8VL/FKnHbdj/zjjMWgazx+dsA/I6gyvk4v+VMmjx5WB2uwpQR"
        "FC151P0o60/GAh+nexe5TxBQRt9vYY7Hiu0VGZ7uAutRluz3GWh7q22H15A5sZAQaDmrfv+wENp+LoWv3I8MSb7VgPYzOigfMAtx"
        "iQt5PMcYxM2nTbPQzKKKIpCiNMfqzwawha6fD+hBAK7ZSlSxjqSbUVu5ODJSpB0p9rgxKWLMhYyjk5G9CwogdySDTDXzufvL4Qx2"
        "vkOduhBdFI2JNEs7OAbgZDHx0mVciEBhFY2JMgsVlgSXv20uUkYIyV5feRClpvWNdfg1y8IzrGgxDMxcADTaQVooUGafmqbNZfIX"
        "9S9J0kWgWi2CyVwII0kGCyFQ5wNAXr7IJ32SJIEQAk3TTCekqipqampQX1+PyspKlJaWoqSkBDabDYqiwGazQZZlJJNJpNNpJJNJ"
        "JJNJTE1NIRwOY2RkBKOjowiFQtlnGJ8vSVKuheI/jrOraG2aiwR2IXPclrPKkqiOuq5D1y8sZnl5OWpqarBy5UqsW7cOfr8fXq8X"
        "FRUVqK6uRnl5OWRZNpUgUXX5M+LxOMbHxzE+Po7JyUkEg0GcOnUKn3zyCXp7ezE9PY1oNJodg3FsBvt3BBcOZqYXIhSwYl/+CZkj"
        "Z5okSbIImKIo2LBhA9rb23HVVVdh1apV8Pl8kCQJsixDVdXspCilSKVS2YmJ0kIp/QqAvH9FUbJ1NU1DOp2GruuIx+Po6urCyZMn"
        "cfz4cXz00Ufo7e29SDJppvBDTzcgc6JMKlaF5wIgZUn9IUJIFaVUdzgcpK2tjWzduhVbt25FQ0MDKioqQClFMpkEpTSrnuFwGGNj"
        "YxgfH8fExASGh4fR39+PRCKBeDyOeDyOWCyGdDoNh8ORvex2O0pLS9Hc3JyV3oqKClRVVcFmsyGRSEDTNMiyDJvNhmQyifPnz6O7"
        "uxvvvfceDh8+jJMnT+oAKCFEppS+hszhczIbJzKXOE0CoNtstt2pVOrfb7rpJvujjz6K5cuXQ1EU6LoOVVWh6zoikQgSiQSGhobQ"
        "0dGBjo4OjI2NYWhoCIODg0gkErMeRFVVFerr6+Hz+eD3+7Fp0yasXr0aZWVlcDqdcDqd0HUd6XQaqqpicnISBw8exOOPP47x8fHP"
        "3W73N2dmZsZnG5LNNdCVZFnWKaX37d27d81zzz136/DwcD0ATExMkM7OTpw4cQKHDx9GZ2cngsEg0umvmhhZlnOGL1ZenVJ6kZ3N"
        "8ld2OwKBADZu3Ii2tjasXr0ara2tkCRJd7vdkiRJB5YuXdoZj8dfjkajnZRSgkWMZ6Vt27bZAfiefvrpP3n55Zf1HTt2pFpbW6mq"
        "qhflnYQQKssytdlsVFVVqigKlWWZSpI060tRFKooSrZPSZK+ku9WVVXRtWvXag8//HDqzTff7FqyZMm1AJrYQiz6izcEAAkEAuUA"
        "PjJJ0i+XSyQf/my+aKv5ylVlAJrH49k0MzPzfiAQCO3ataspFotRYpZmXOKiKAqmp6f1V199dRTAIKV0I6VUKoJouCTJvkwI0VRV"
        "/d6zzz77n3v27PlxNBq9Ph6P61jENyUppVppaalcUlJyPyEkZLfbJxOJxM9nE7IsOIAAdLfbfevMzMxPp6am/kVRlO+EQqE0IURZ"
        "LAB1XU9XVlYqLpdrFSGkpLq6emJsbOz0LOi2eU/lTBcjHo8HJEn67Lbbbiurra1FMpmUF1OLdV2XHQ4HDh069BNJklzJZHKnQHFd"
        "NkwS4akcgLcuM+dhvHbN577HfNkmiRCiU0q/6/F4bnG73aWxWCy7+0UIyRIDIoU135ckSdkUjxBijBG1hoYGGo1GV1BKP2YMjDRX"
        "KZTnCzxCyD21tbWBDz/8sG379u1lbW1txG63k8nJSUQiEWiaBk3ToOv6V/JbC+Oflw801ucEBn+Oy+VCS0sL7rrrLjz00EPkwQcf"
        "JD6f79EDBw6sWLZs2alQKJSYF7s1x/Z03bp1ZR0dHcdeeOGFT+699947Q6FQliCIRCL49NNPcfToUfT396O7uxs9PT2IxWLzbkeq"
        "q6vR0tKC5uZmtLS04Prrr8+mlqqqauXl5bLT6fwPQsgZl8t1MBqN/nyutlCZjwU4duxYOwD/G2+84fd4PGhpaYHf74fD4QAhBNu2"
        "bcOOHTsQiUQQDAYxPT2NYDCIvr4+nD17FoODg+jv70c0Gs0SCZxM0DQNdrs9SyY4nU44HA54vV40NTXB7/ejubkZDQ0N8Hq9KCsr"
        "Q0VFBRRFQSKRAKUUDocDExMT0pkzZ/DBBx/8NoDrUqlUDy4c0tQWSwJ5LPWkoihPpjOJrhoIBLBmzRps2rQJW7ZsQU1NDVRVRUlJ"
        "CSRJQjqdzpKcog2LRCKYmZnJfobDYaRSKbhcLng8HpSUlMDtdsPtdsNut2fNAaU0a/8kSUIymUQ0GkUymcTJkydx4MABdHZ24ujR"
        "owiHw5BlGZqm/RGAf8WFQ1OXHEAO3iZkXulywuTImMvlQiAQwLXXXovVq1ejqakJS5cuhd/vh91uzwKg63rWEXDOkDPa3LaJ9k1k"
        "nAFgcnISPT096O3tRW9vLz7//HOcOHEC58+fRyp10Vta/OjGKWQOKc3MRY3JPHjeZ5xO5zdffPHFxoGBAc++ffvQ29uLiYkJy4YN"
        "DQ2oqamBx+NBU1MTfD4flixZgrq6OqiqClmWTQHkjigSiWBgYAB9fX04d+4choaGEA6Hce7cOUxNTVluL9TW1tLNmzeT7du3Tz72"
        "2GM/HBsb+19CyAGW1umLBeBzTU1NX/T19T0yPDzclEql0qdPn5Y//vhjHD58mBw8eBDT09OLFqA2Nzdjy5Yt2Lx5M9rb2zWv10sI"
        "IenW1lZ7OBxuvuOOO/reeuutxVFhQoguy/Jml8u19913372htbW1UZZlKZFIwOl0IhQKYWRkRO/q6pIOHTqEY8eOYWBgAENDQwsC"
        "lsPhQFNTE5qbm7F+/Xps2LABjY2Nus/nk7hTqa+vhyRJe20228f19fXR/v7+nsVSYRaaEUopfdhut39/69atpe3t7S/s2LFjZ11d"
        "HZFluc5ut5NIJML3LWhvby/p7u6mo6OjGB8fx8DAABkaGsLo6CjGxsayNk7c41AUJavWhBA4HA74fD7U1tbC7/fD5/Pp5eXlJBAI"
        "kBUrVqC6ujrLiDudTsRisSlN01Jnzpw5sm/fPuXtt9+u7evr279s2bKnTp8+PTMXVmY+klS+ercD+AsAAVmWK6uqqt554IEHblyz"
        "Zs2Z5cuXr/Z6vRIASVEUOBwOSJKERCKB6elpJJNJaJqmp9Npmk6naTweRzgcVqamppBMJuHxeOB2u6nH49FUVSXMTkqKohCHw4Gy"
        "srLs9iffEyGEaP39/aGenp7z77//vu31118fiUaj1yOz//tLAA8g82b7nOLA+cryCSGE7t69233gwIFlY2Nj30DmxeflAJSWlhaf"
        "1+sdvvrqq9+7+eab721sbJyuqakZLC0tVRVFWa6qKqfDsrt00Wj0IupelmU4nc6LTiPouq7HYrEUgM7R0dHK6enp+i+//LL3nXfe"
        "OTo8PHxPf38/QqEQf+/uIICfNTQ0fHHu3LlulunMmVCYbzpLE9OuQCAQGBkZ+a14PL4emRP4K5DZRw4COFpXV1d64403brLZbKit"
        "rT1eV1d3trGxsa+yslJOpVL3lZSUUFVVkUwmSTgcHnK73a90dXW1BIPBqv7+/rZIJFI9PDyM/fv3v43MYfOVbBxfInNy4jOv13t4"
        "586d//PKK6/ETeZN50P95p3eF1ZW5yHEE088obz00ktlwWBwXSqVWk8IuVrTtGZkXlOtELYAdADVLpfLy0MZvrOn63ovLpw8VZF5"
        "6WeCEBKVJOk4IeSUzWY75Pf7z3Z3d4cN52bE/5xEMU9U1kITdZIQcOtm5MAzzzxjf/755ysmJiYqUqmUR9M0VzKZrIzFYioyb4Ta"
        "kTnSO+N2u2OKooRkWY45nc7JxsbG0JEjR0JmxzqEVFXcD1kQHu9ScoZmUqpZGNWCGBoDUDBIF71Uk1psMpaYgGwEwGjwLylQV8qV"
        "cqVcKVfKlXKlXG7l/wFaAL8Ot/kOrgAAAABJRU5ErkJggg=="
    ),
    "bk": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAU5ElEQVR42u1de3RU1bn/7XPOPDOPZIIhCUMmxgCBAAaxvNQbqrEa"
        "obCuV1qprS20gm8K2t7iunfR5e3F21pabFnXyl266gtKCW2lrUgrKjfy0IKCKCYkM8nMZGYSkkwmM5lkHuec7/6Rc6aTQEhChjbe"
        "Zq+1V+a89vn273zf/h57fzsAUI7+wjBRRl24CQgmAJwAcALAK1vYeB6fuc8AeKRUNgHg6AsByAKgU35PADhKuq4G8A6A/QBs49Xc"
        "Gk92IAdAA0Cv/L0/TYRvU87pAAjjBUhhnH1MWalJ5dinHAOAN+38uCnjBUBVWUxTOM2gADc/TZwfBNCkHHcD+AMAf9qz/9AirIL0"
        "hzSRHa4+ozzDT3DgXz+eF0Cfwn3qeKjSmAQgpl3zTSiRCwsPoATAXADXAPi3NI5bo4j4XABTJ5TIxYsEwJV23JD2++NBxxN24CXE"
        "WaPQpks7r1fOjRsTZrwCqLptMoBE2vlEmralCQAvTZMKXEHa+UIFOHG80T3elAgAXA/ggAKkrADXB+BXipL5u5sv4xFAFZDbAUQu"
        "Yf+5FU08biRoPBnS1wIIponqYPCSyt9GAHaFZu4fHUBOebcewNFBQNElQNz1/xFAThHF9MoN00kVwPWX4LzBVb3nC5cQZTYEPXza"
        "O8cNgPwIOGE4G65WURjSKAB8+SIOATdCByEjNuVYPRFe6bDEGIPVanXIsnyVJElWItIIghCUZTkCoL2np6cjLTSlcoeqYR2KYhhp"
        "Z9T7FgAwA4gqfVF9ZRmARqfTTeF5PofjOIssy1kcx4V5nu+xWCznfT6fX5ZlOQ1Mulz78nI4kKlakzEGg8HwzwB2A+i4CLdIAOoE"
        "QdgjCMJGg8FgT2tHq7R1V1rH5RFwoHpPFMCidK7ief5mnue38zz/vwA6h3jeA2CvTqd7xG632xhjl20XMwXAT0YZV2MASK/X/1Ms"
        "Fvt3AFUAUFpaisLCQkmv14OIEI1G0dnZyTc1NSGRSDkVYUEQfgPgOVEUjyvn/gVAzSBPZCTeSi+AeQCaOY67lzG2QZKkmerH5Xke"
        "JSUlUm5uLkwmE+N5nuLxOItEIpzf70cgEACANgDPL1q06AfHjx/vS5OqKwIgA8AxxiSe5zeLoviDgoIC7ktf+hItXbpUmjJlCl9Q"
        "UMB0un4Xtre3F52dneT3+8npdMqHDh3iDh8+zIXDYQBI8jz/K5PJtKG7u7sUwPE0URoOwFRIi+O4rQDWyrI8HwDMZjMWL14s3nzz"
        "zWzGjBmc3W5nNpsNJpMJHMchkUigp6dH7ujokM+cOcPt2rUrVltbaySid3Jych7u6ur6ZDQgjhZAjjEmE9EPAXx3zZo19J3vfEe2"
        "WCy8ynXxeByS1P9unueh0Wig1WoRj8eRSCTgdruppqZGrqmp4X0+HwA0CoLwgiiKmwBMGg0HchzXJ8uyBoCQl5cnrlq1irvzzjtZ"
        "aWkp02g00Ov1EEURiUQCkiSBiMBxHARBgE6ngyzLiMVi0vHjx+NPP/208f33328FsAzAB2ljdMYA5Bljkl6v/7YkSdueeeaZ2J13"
        "3qmPxWKcRqOBy+XCmTNn0NzcjObmZoiiiOzsbEydOhXz5s3D9OnTYbPZkEwmwfM8Wlpa6MCBA/KOHTv48+fPQ6fTJhOJpIZoZKMI"
        "z/OQJAk6nQ7r1q2TVq9ezV999dVIJBLQaDSIxWJobGxEfX09PvzwQ3i9XnR1dcFms8HhcGDRokWYN28eJk+eDMYYent7pS1btvB7"
        "9uwJ5eTkLG1vbz89UhBHokQ4RTymA+j68Y9/HOvo6KDm5mb6y1/+QuvXr6f8/PwhB33GGC1YsICeeOIJ+uCDD8jn85Hf76dAIEDH"
        "jh2T7rjjjtS9HMcNG87neZ4AUHl5Oe3bt48CgQC53W7y+/3U0NBAO3bsoM9//vNkMpku2c706dPpZz/7GbndbnK5XPL58+fFxYsX"
        "vw3g3UWLFhlGai+OBEBGRByAvZ/73Od8gUCgt7m5WT5y5AjNmDFjQMc4jhtQ1c6qNS8vjx599FF6++23yev1ksfjoebmZnrsscdI"
        "r9cPCyJjjADQTTfdRKdOnSKfz0cej4fq6upo+/btdO21114A9mCa1Kre841vfIMaGhpkt9tNXq/XVVpa6gbwnxzHjUgzDwcgr3Bf"
        "tV6v/+TUqVNvd3Z2Un19vXjdddcRABIEIdWxS3FNOtG5ubn0+OOPU2NjI7ndbvL5fLRv3z4qLi4eEkT1Y6xevZoaGhrI5XJRIBCg"
        "vXv30pw5cwaAzPP8sDSlf+ANGzaQ3+8XQ6EQvfPOO7t4nj+Vn58/cyTmzaUAZAA45UvsWLRoUev58+fjLS0t9OSTTw7o1Eir2jn1"
        "eMmSJVRbW0ter5f8fj+9++67dM0111wAovrMPffcQ16vl1wuF/n9ftqxYweZzeaLfqSR0qM+8/zzz5PP55MDgUBo6tSpxwA8rtiI"
        "/FgAhDIenF22bNnmQCBATU1N8ty5cy8A43KBLCwspJqampRIHzlyZAAnqh2srq4ml8tFjY2N5HK56KGHHroA4MupgiCk2m9ra6O2"
        "traOWbNmbQRwSAGQXS6AqvKYBsD9pz/96WBXVxft379fVr/6cGIyUoVgNptp9+7d5PP5qKWlhQ4ePEg2my11vaKigurq6qixsZHa"
        "2tro8ccfTwE8VhrUD1RSUkInTpygYDDYXV1dvQZAw6pVq/gxh/QTicTVADqys7MXCIKAxsZGRCIR8DyPkZodQ07DSRI4jkMkEsH6"
        "9etx9OhRAMDcuXOxefNmSJIEs9mMbdu2ISsrCyaTCXv37sW2bdugDC1jpkF9PhKJIBKJEM/zlm9+85tbAXR5vV7rmAEkIj0AYzKZ"
        "7GOMgYjAGEOaDzmmIssyeJ5HOBzGgw8+iPr6eiQSCdx9992oqqrCmjVrUF5eDiLCoUOHsGnTJhARiAh/jQeMYRpQ6YfqsYiiKMdi"
        "MT8ATqfTycNZKcOKsMFgWAjAWVtb2x4Oh+mFF16QxyIyw4nz9ddfT06nM2VnfvTRR+TxeOjYsWM0adKkEduLo3kvY4zmz59P586d"
        "o/b29o7y8vK7AXxKRGwsHEgKgD4AYn19/aZ4PE4zZsxIWfCqGGWiSJIEnudx4sQJvPLqK9BqtcjJyYFer4dOp8OLL76Ijo4O8Dyf"
        "Ec5LF2EiQkVFBaxWK0RRNDPGFgL4WPlQbEwi/Itf/CIAoP61115bCoCVlJTg1ltvTYlyJova5rP//Sza2trAGINWq4XT6URNTQ3U"
        "ISRTRaXfYrFg7dq1oiAIYIztdDqdC/V6/WvKu/ixcKDw5S9/WRIE4eDp06er4vF4Hcdx7Gtf+5qs1+shy3JGQVTba21txf79+6HX"
        "6yEIAnbv3o2Ojg4wxjLGfaoEybKMtWvXwuFwMMYYvfzyy/a+vr5ocXHxIYX7pLFwoERErKysrMbj8QRefvllr1ar7Zs1axa2bNkC"
        "IgLP8xnnRMYYXC5XSlzPnj2b8XdwHAdJkrBy5Ups3LhRliSJj0ajLU8//XSpIAhv1NfXB9JCbGMPJnAc9y3G2Adnz57t8nq95PP5"
        "5K9+9asjdueGM6zVqg7q9913H7W2tpLH46Hq6uoB18Zq+6nG87x58+jcuXPkcrmoo6OD7rvvviCAA+vWrdOMdIgbUTBBdekEQXjt"
        "pptuCvr9/qjb7aa6ujr5K1/5ygVu0Uh8UEEQLulBfP3rX08BeMstt1xUe6ptjEYrq/eWlZXR4cOH5aamJjEYDEaeeuqpAwDqrVbr"
        "/NHoiJHOiTAAXEFBwSQAJ6qrq98KhULtbrebWlpa5M2bN19gFqSDOjgCMrjq9Xoym81ks9mooKCACgoK6KGHHkqFqlauXEk2m42s"
        "VmsqajMUOGodzKXpNKxYsYJOnz5NLpeLwuEwvf766xEADVqtduVowBt1RBqAnJ+fP6u1tfWl2267Lbxr166KcDico9PppJqaGv4n"
        "P/kJmpubU0FPWZYv0JolJSUoKSmB3W5HXl4epk6diilTpsBisSArKwtGoxFarXaAiRSLxdDb24toNIpIJAK/3w+Px4P29na0tLTA"
        "5XLB6XQOeFe6klDHOwB44IEHsHnzZpIkiRkMhsTx48ePPvroo0vb2toeTCaTz8qyrM7wXZFJJR6AZLfbS1taWl5dunRp3quvvjpZ"
        "EARDPB5He3s7du7ciV27diESiQAAioqKMG3aNNx4441YvHgxJk2aBKvVCqvVCkEQIElSqnMqAOmeTrrWVc/xPJ+KSnd3dyMUCiEY"
        "DOK9995DbW0tGhoa0NTUNIDwOXPmYNOmTVRVVSWLosjn5OTEt2/ffvL73/++FsBOAP+TNj16RWflBADijBkzCuvr63dXVFSU/fSn"
        "Pz153XXX3dLd3c1lZWUJBw4cwO9//3vcfvvtmDVrFqZOnQoiglarhSAI6OvrQ29vL+LxOJLJJKLRKEKhECKRCMLhMCKRCEKhEAAg"
        "OzsbZrM5Va1WK0wmE7RaLbRaLYxGI4xGY2r+g+M4+Hw+fPrpp9i/fz/eeustPPzww7j77rvJZrMxIoJGo2l/4oknuOeeey6Yk5Pz"
        "7VAo9LoSNB6VjXS5AKY40eFwZLvd7h0AKjdu3Dj5/vvv13AcJ2m1Wl6WZRiNRsiyDFmWIUkSzp49i5MnT8Lr9cLtdsPn86GlpQXR"
        "aDTFiUMZyoyxFOcZjUbY7XYUFhbC4XCgqKgI8+bNQ3l5OTQaDRhjEAQB0WgU0WgUOTk5MhFxWq22xePxvLNs2bKr2traHFar9Z7u"
        "7u4PRst5mQAwNSZyHAeDwbA6Go2ufeWVV0IrVqy4y+/3y1arlYtGo/jkk09w6NAhHDlyBE6nM8VZw9mBqriqrtZwxWKxoLS0FAsX"
        "LkRVVRXmzJkDi8WCnp4e4jiOabXa+GOPPfabPXv2TAHgys/P/25ra2v75YKXqbUxqXTUX//611oAiMfj/9HW1kY7d+4Uq6qqhjQj"
        "MlkvZhdWVlbSz3/+c9nlconRaNRPRBUAnsrNzf3iWFYjZJIDBxBhMplm9Pb2Lp89e3ZEo9E8e/LkSelifqTRaER+fj4mTZqEq666"
        "CiUlJXA4HAPGOp1OB0HoX7ojiiLi8Tii0SjC4TBCoRA8Hg+cTifa29vR0dGB1tZWRKPRi3pSc+fO5QsKCv7r4MGDXpPJ9FZPT0+d"
        "wnUSxrjeOpMAygCK0Z+ONWCJhlarRUFBAZYsWYIlS5bA4XCgoKAAeXl50Ov1kCRpgLmjii/P8yktPPg6x3HgeR6JRAJtbW0IBALw"
        "er04evQojhw5Ar/fj3g8foHrJstyOYD6tDU2GG8AngFgAkAzZ85ky5cvxw033ICysjLodDoYDIaUfSiK4oBgBBEhmUymuK2npwdE"
        "BLPZDKPRCL1en1IQ6ZEbjUaTsvd6e3uRSCRw7tw5HDt2DK+//jpOnTql0plE/yrYT0c6af43BVCn05XE4/H67Ozsru9973uT7rjj"
        "DjZ58uTUwiK9Xo+enh643W50dnaira0NLpcLXq8XLS0tCAaDkGUZyWQSiUQCsVgMAKDT6aDT6VJAZWdnw263o6ioCCUlJZg8eTJy"
        "c3PhcDhgNpsRi8VARNDpdAgGg3jjjTfw5JNP+rq6uqZoNJo5yWTy4/EGIANANpttZjAY/OLHH39cV1xc/FpnZ6coCILQ19eHc+fO"
        "oba2FqdOncJ7772HYDCY0ciK1WrFwoULUVFRgRtvvBFlZWXIysqCKIpibm6uEA6HqwsLC+fm5OT8UVlAlLEsz4wt8X3kkUd0imgt"
        "jcfj9OGHHyZ/9KMfUVlZ2QX+61imIYfT6jqdjqZNm0Zbt26lEydOJOPxOPX19d2s0JbR9IiMcqDFYikNh8PTX3rpJYPb7a755S9/"
        "KTqdziFXwer1emRlZSEnJwdFRUUwmUywWCwwm82wWCywWvsnxFTPJBwOp357PB50dXWht7cXfX19QxLmcDjEe++9V7Db7XetX7++"
        "x2q1NnR3d7syxYGZViIl6E8IZBfj6ry8PCxYsABlZWWw2+0oLi6Gw+FIrd1L165qZYxBFMWUplY9FVmWEY1G4fF40NTUBL/fj7q6"
        "Orz//vvqwskLzBnFpJqD/sRFbjxqYYfSVpZqxsyePRs33HADKisr4XA4UFhYCKvVOsB0STdZJElCMplELBZLKQODwQCdTgetVnuB"
        "aZMOeiQSgc/ng9frxeHDh1FbW4szZ86kT0/IAGYDqBuvABYDaOJ5HpWVlfJdd93F3XrrrcjKygJjDDqdDrFYDKFQCH19fWhvb4fb"
        "7Ybf74fP50MoFIIoiqnQlWrGmEwmZGVlpeZHrFYrCgsLMWXKFBQVFSEvLw9GoxFWqxUGgwHxeFxdPIk///nP+O1vf0uHDh2SRVHk"
        "tVpteSKRODsuAbTZbLOCweBjW7du/XTdunVPJ5NJSRRFXhAEBAIBnDlzBqdPn8abb74Jp9OZMlfGUrRaLTQaDYqLi1FVVYWKigrM"
        "nj0bdrsdkiRBEARJo9HwL7744qObNm26Pjs7e1soFPooUwBmVAtXVlaaVq1axRPR/Fgs1uN2u5O/+93v5BUrVqRWXA0X4ldD9GpV"
        "rw2+fil/uri4mJYtW0b79u2Tm5qakvF4PEJE1zPGsHz5ciMyXDKZqcTPnz/fCECzYcOGvStXrpQBxJUvnZoUUsPtY50YGmoyKm28"
        "S1RXV0sPP/zwawD0lZWVelyBlLaMAqjU66HswJEGmsgYS2JkeSCXW2UAIsdx4iAw3wRQmUbfuAUwfYUBZzQav4D+bZuiuDBVS1Kq"
        "fJmgqs+p7QzOsesDcNBoNC7fsmWLFlewXAkAB7dVAuAJAH/E0LnAEvoTrJP46xYn6eCIyvkEhk5I7AVwEP27fcwchqbxzYFISwcb"
        "VKYD+BaAN9Cf99uBkWVoXgzwTgBORUQfAFA2xLByxcDLlBkzUjAHBzAF9O/QVgRgCvr3RcgBMBlAnvKXoT8dqx3AeQW0VgAt6M95"
        "a8LAzSmQqWDp35sDh5ycx8jSY9UkbMMIaEtv82+aOP633nhncEopG1TTXS4CELsI+GxQWxmJLH9WABwO0EsN+uq4N67KeNv6aTBg"
        "475MbIM8AeAEgJ9tALOysrjP0pgz3gpD//bC8xRjdOI/OoxWCx/Y/cP7q1f/64dardacSCQmuHCU5f8AXf731NLlZCMAAAAASUVO"
        "RK5CYII="
    ),
    "bp": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAEbUlEQVR42u2cyYvUQBTGf0m3juM6Oi64MSgKLiBuBwc9ieCOCF4E"
        "r4L4F4gIcxFvIrhcPSmI4k0RRNGLoogIHlQED4oo7vs2k048pB5dRGfopdKpJPWg6Ga6u1L15XtrvQw4ceLEiRMnTpw4ceLESafF"
        "y8G6InebGpMK4A/zmT/CZ5kv2ga2+UCo2OYDPcBcIAAG1d8jS9ZrraquBo4B94EPwC/gLXAHOAIszYHpyQS8KjAA/NSY9r/xCdin"
        "qXTpwasA3cB5DaQAqCl1llEDhrTvHHUg1jd/QIEyqIAaiYGB9p2NFtnwzFR3IfBZY1rUwBAAHwOT1FyeDUzI4pp7FAhhEyCIt14E"
        "rC+jZxbGTAAeKDCCBtmnq3IInNVCIK8sDPQUCD3A9BZVUH6zWDmhsGwqDNAFjG0zphun5qGMAIpDMMHmUgEoG34FPFfvm1VB+f4z"
        "4GsZs5Kqet2rBcrNOJFQxY07FHjVMjHQU15UgAxpzYkEyoFE2nylCGF8ZfzPJALjVsdxYHTWoUyn2X7KAHh69nK4DGmdbG6XAi5o"
        "In0bCcQA+A1sKDKIEvh2Aw81uxUZGDLPTU2NvaKyb3eLqVsjBYYhYFNRWSiMuGPIcQzHwisZJwepgjeXuEQfGbB9w5W43gBT2kwP"
        "rYsDZf4lwKiUb9J44hpjR1nYqQvNUbYpSpEdY4GZRctEBKxRiVw4rRy7WjQVFhlKeWNe4jpRUQCUjdQ6tJ9a0VQYrfRUS1m1flAv"
        "kRWmn0YA6wKe0twJXDNhTAjcyyIT6YQKe8Af4LZ6H6Z0o26k7OUzT+XWqmA6MMjCmhpfqPfOFLJjQTZ1wnAxQbKQg0UvaUkxdRpw"
        "11BOLLbvKvE5cyZFVb+D1wmBd8AlDdRWvaXYugC4CHyjteOBXNnABcA1gwUFvYPrAjCjiDZQwNsKvEypGiPzPQH6EyldIcDbAXxX"
        "mxwyDF6yJvgGWFcEh+JrzPtCOoXUkUDsz7M6y6JXAh87BF4yrHkBzMsjiL4Wrpg+QGp0iJm4SVwjzNWZsdztkxmBl1TnQ3lioRjt"
        "fuo9z2FGAEqK95m4m9WzHURZYAW4nDH7kiw8nagMWc2+7fzbepHVkM6vn8Aa21VZ2sxukc7hebssPKdpiLXsW03cpxJZwL5kuvde"
        "C2uMgmiC0lIQ2Kkqz4FF9kYKuL3ANltVF2AM8Mgy9iWD6xtY2HwkDN5sGWj/Kzb8AVaZdia+od8vU6+hpVoSEXeyLrUJQL0gusJi"
        "AKF+Xrw8YbczZ2CNuJy+2PJg1dM0pYLBM2rfwKKmA7MsD1RlrX3Ej5lhiwqjGDjZ8jxd1jqNuNUYGxgoMkWpRWC5CofARDWsCqSn"
        "5iFZ19bYaxuAk8mXGF1vO6dXEgr0JAJXW0XW12NSY0wc/3VhwUN/TRQ9utPwTu0E0n3AfNLv/zPBwArx+fFrLHneuPTiGZojTz0p"
        "kWOeEydOnLQvAwMDvkOhVU8Uuf9h2AZ4kQdw/eT+Podii2q7Zfa3BVXfu/YXVX6GWfjrx2QAAAAASUVORK5CYII="
    ),
    "wp": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAALLklEQVR42u2cXWxU13bHf2vt8bfHZri2p8HGrhLsOAFfGxE7Surc"
        "C8FKWj5KqMvlSk0jVU25iaJUal4iVZW4qA9tpPuWNi198JUSxH1IcmkJyscLiER1UhySlkRpUIEoKAGMAxgzg+3xnL36wDnEcIEY"
        "PJ6xYLY08njsObPP76y9/2v9z94jwAaKbcattNQJEPzFz9dX/Os//s0/CPCTIpabauacKwuC4PjuX/9KizhusdXU1CwE/jBWRHHT"
        "TQDGxsastNRVFEPwFocxQCYT+CLAWbYiwCLAIsAiwCLAYisCLAIsArwz23wr5eQ6F9VH2X8R4PWbA4LwcaO/FwFeYxrxIZxSoANo"
        "AKqB88Aw8D/h32V6LVps3wMB2CIig6pqqmrOOQufT4nIPuDn13lfofqcoMBmdNSRRuDfVdXCyDJgCsiGPw0wETFgR9jxQkK8AmCs"
        "wJ2IA7tUtdt7H4gIDz30kD744IOx9vZ2Dh06xIEDB2xoaMibGar6Z977HwHrwmEvd+pwjpT212FkZe677z7buXOnnT592oaHh21k"
        "ZMROnz5tJ0+etO3bt1tzc7MBmfD/XypgGlbwIRyd9Kpw2AbNzc3+k08+sXPnztnRo0ft2LFjlx9Hjx61sbEx27dvnyUSCQ8EqjoR"
        "ik0hIF4B0BUoXfEi8ncislxV/UsvveR6e3sZGRmhpKQEEbn8UFXOnz/PkiVLiMVism/fPi8iJWZ2CtgfHa8AACuAlkJcvSwQF5EH"
        "vPeyaNEiWbNmDaOjo5SWll7zTSUlJYyNjdHf3091dTXeexOR3hBetpCqXMjwbwBob2+XWOzGWiYieO+pqKigra1NLr0kjUDVnVoL"
        "TwGTAIlEAhHB7IfFVFWpqamJfs3Mh8ok3wAjSt8BxwEOHz5sIjMbgdlslsOHDxuAmR0B0nciQAdkzWxYRPjyyy/twIEDxONxguDa"
        "ARUEAfF4nP3793Pq1CkLI/abcEqIFTIXLFQeZWb2b6oaTE5OuoGBActms6heuzvOOVKpFAMDA+a9d6qaBgbmQxJdKBVeOD0J3bVr"
        "l+zfv5/Kykq8vzIj8d5TWVnJ7t27+eCDDySMvhLgZ6GIFFSFXQEuVjPwtqpu8N5LVVWVbNu2jdWrV19W3GsN4aamJqqrq/nwww/F"
        "e6+q+lMzexB4KxSkfJV1V+SBrgARv1NVH/HeT3V0dLgdO3awbt06vPd4738HYKTQ5eXl9PX18fDDD/PRRx/JuXPnplR1iZktBHbf"
        "7gBdeHK/FJG/NLNsT09Pyc6dO2lubmZ0dPS60Tc9D0yn07S2tvLYY4/x/vvvu5GRkayIdIee4dC0z8kbQMkTvABoV9VPzKyspaWF"
        "N998UxsbG0mlUvxQIn11KlNbW8uhQ4fYvHmzP3PmjALDZvZj4DTfG7RzKoJhMfCTfIhIFBGbgQozsxdffFHvvvtuLly4cFPwAGKx"
        "GOfPn2fFihU899xzamaBqiaBPy6ET6h5CHcPlKnqn3vv7Z577tGVK1feErzpaU06nWbNmjU0NDRIEASmqk9P+7zbCiDAj0WkBZD1"
        "69dz1113kclkmGkFcq05cXx8nLa2NlatWiWAqGor8PthxMvtBnCx994BLF68WK6ltrcC0cxoaWmJ8sUqYFG+89u8AFTV3zMzcc75"
        "xsZGpqamcgIwCAIWL14MYN77MiCZ73kwX1eqFqCiosKSySRBEMwaYJRgL1q0SEKbH6Dmdi3lUgCZTEbOnj2Lqs7IvpqJvXX27Fkz"
        "s+hqpG83gBGlMyFAHR4eJhaLzRqgmeGc48SJE+GIliD6nHyaDHkB6L3/b+fcBMBXX31lzrmcABQRjhw5EkXjCPC/kQdxuwCMTuQL"
        "M/scsHfeeYczZ85QUlJy6wf1nvLyco4fP87evXsttMc+Bk6G53TbROBlx8d7/x8iIp9//nnw9ttvE4/HyWaztyweVVVVvP7663z7"
        "7bfmnBPv/ZuFqEQkTxfJgPtE5D+BeENDg7z11lva0tJy0xVJNpslkUgwNDREf3+/v3jxIsC3ZtYTmgpzXY1cUQvnw42JbPzTQFpV"
        "16ZSKTt48KA8+uij1NfXMzExcV03+urIW7BgAV988QXPPvusnTp1ClVVM/sr4AD5uUdcMD+wBPjIzJap6tITJ074wcFB6e7upqmp"
        "icnJyRvmht57amtrGRwc5Omnn+bYsWOmquq9/2fgV1y6NxLkcdTm7cZ6tOp0Clg8zVWRzz77jHXr1jE4OEhFRcXv2PnT4VVWVrJn"
        "zx6eeOIJjh8/TiwWi04kBvyIS9Z+3ldauDzNgR7YJCK7VLXHe2/ee1m1ahWbN2+mu7ubysrKy6nJjVyYuro6zIyvv/5azMw757qB"
        "PwlTmKN5UOG8GarC90svtqrqL8MIC1auXOmeeeYZHnnkEaqrqxkbGyObzd4QnplRUlJCPB5ndHSUvXv38sorrzA0NBQATlWz3vu/"
        "Bv4ljMrsHJ5XXkQkcqIjeJZIJGzr1q1u27ZttLa2Mj4+TiqVuryQaCbmQSqVQlXp6Ohgw4YNlJeX68cff+yz2awTkbWhEh8IIfq5"
        "jkA3x/D+VlX/3nsf1NXVyWuvvab9/f2k02kmJiYQEZybeRei1Vpmdlm5H3/8cdrb2+W9997zmUzGVHW9mZ1k7u6RzDnACN6TIvJP"
        "ZuaTyaTbsWOH9PT08N133+GcQ1VnZahGIFOpFJ2dnSxdulTefffdyKj9I+C/gCNzAHFOAUaCca+IvCEi5WVlZQwMDEhvb++sS7jr"
        "gUyn03R2dtLY2Ch79uwxVXVm9lPgN8CFHBcMcwowSll+o6pLvff+hRdecE899VTO4V1ta6VSKVasWMHw8LB8+umngXMuYWaNwG/J"
        "7T3jOVPhaOj+qaq+7r0P+vr63Kuvvsrk5OTliJmzcufSInSCIGDTpk128OBBr6rmvV8NvE/uNurMiQpHB60UkR1AfWVlpW3fvl3r"
        "6+uZmpqaUak22+EcBAE1NTW0tLTIG2+8YWYWA1qAV+d7JRIlr1tEZJmZ2ZNPPumWLVtGOp2ec3jTE+0LFy7Q29vL+vXrnZl5VX0U"
        "2DStJp93dlbkflSp6i+895ZMJm3Lli0/WN/OVQuCgOeff554PO7D6uYXYS1u8xFglCb8AdAGsHHjRl2yZAnj4+N5i77pgnLx4kW6"
        "urpYvXq1MzMTkYeB+8ML7eYbwCjb3+i9VyDYuHGjjI+P31SSnOv5MJvNsmnTJgmFowJ4Ypq9Nm8ARsN3oXOuH6Cnp8e1tbWRyWQo"
        "VBMRpqam6OzspLW1Vb33qOrPuLQb1M8ngNH7+4B6wNauXSsLFizIyc3z2QCcmJigqamJvr4+CV+7F3go1y5ULiIQEVkeBIGVlZX5"
        "jo6OgsK7OgqXL18uqhoEQeBUtTOHU1dODuTDzrYDUldXZ0uXLi2IeFxLTCYnJ+nq6qKiosKHyfa9V83bBQUY1b0J4F6AZDKptbW1"
        "OVu6kQshqa+vp6GhQcPXloXzYJCr+jgXYbIozPZ54IEHpNDgri7vSktL6erqijrVyqUdAvNCRKJOVYtIJWAdHR0FH7pXzC/eU1ZW"
        "xv333x/N1YkwpSFXEZiLHevVUQFQXV0dy2az3GjTTL4rknCXk3Bpi205Od6gmAuA8ehJMpkkmUxSVlZWsCT6aoCJRIKGhobpL887"
        "gAv9pbtFtnXrVv/yyy/PizRm+hz4zTffAPhwL15ivgGsNzMFdGhoiHncNFwR1jBfAEY15Qjwf0DgnNOZ7v3NZzoT7oKyUDTP5/T4"
        "OVLycvK8vWAW5zo5y75e4UjnYgh74CJ3aIvNo0jOm7bMR4B37JeBFb+AsQiwsO3/AZdwjrQIkldJAAAAAElFTkSuQmCC"
    ),
    "wr": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAIDElEQVR42u1cX2iU2RX/nXtnJk6GpGbCZJLtUtIuUpEtFRUsLqmV"
        "QvqwqJW6C63kwdZgBWGlWvzz4lsJ1NRCfWrzEAqldAuGCK2Egr60Sw0i1XZFdwXLtigazTgzmcnMN3PP6cPcbzom2WScmW9msvv9"
        "4DIzmfnOPd/vO/eec+49N/Ti/p9/Ax9Vg40hHQpJeu7pD/9z64Yin5LacHf6wvdzc49+RyLXAz4dr4gP5xS9+a7zt1+/9x2fjBoh"
        "cl75LNSJ999/R/ss+PDhw4cPHz58+PBRA6hJsqRBukgT9GjJQ1grL9Sr3BjZ76uBXkMPXYcenylr/lwMYbJD4nUA4wD6iIiJqCxT"
        "RCAiBOA+gJ8CSFdc5752A/gFgDeISCouR4UcsXJuWznFFeT0A/g5gNdX0eMhgJ8AeFFxXcvgDpf3rCJrte/aoR601wbt5+9Veb3b"
        "hpbICdnPP67y+nermA6qRj2Lqe7T+4K1CB4YGNAdHR1gZiilkMlkMDc351pJJwC2DQCMfQ3b99zX16c6OzvBzCAiiAi01kilUnj+"
        "/Dkqfr+qnHg8rsLhcFmPbDaLp0+fsiW6p5FWVPdqtFLKMHOAiMzExITetm0bkskkotEoLl++jGPHjrk//aqIfMtajnszBQCblVJa"
        "RNTY2Bjt3bsXiUQCWmsYY9Db24uJiQmcPn3a/dvXAThWd3HlENGgiGillLp06RINDQ0hkUigt7cXMzMzGBkZIaWUYmbTVgRWzqNa"
        "63ILBALl+ScYDALAORE5t2TeFfsQ4DgOAUAgECjLEJGyHCJCIBAAEf1shflbXIs1xiyTo5TyzNl5th/iOA76+/uhlEKhUFizL601"
        "YrEYHMf5/50SwXEcxONxiAjy+fyacrq6upbJ8RKeEKi1xuLiIrZv347x8XHcvn0bRCQiy50elb7Ajh07sHXrVmSzWWity3IymQx2"
        "796NsbEx3Lt3b005u3btwqZNm5DL5cpy1h2BrvUUi0WMjIzgyJEjaw6dfD6PdDqNlcIYIsLo6ChCodCacnK5HBYWFqCUgjFmXRAo"
        "FQ7lpQYA6XQaqVSqGme0qsWkUimsZHmryRGRl3TxIp2rm0BmDrpKnTlzBl1dXeUwpNVwCZyfn3d1FRsFtJUFvgaARIRv3brVztt8"
        "bO/3tXZJ5ZRVaiuAa0TUQ0QmEononTt3gplhjFk6fJrDFDOCwSAKhQJu3LiBfD5vAGgR+S+AtwB8UqF/yyyQ7QP4B4C9IvIHIvpi"
        "Lpcz8XhcX7hwAblcDoVCoanDWUSwYcMGMDOOHz+OQqHARKSZ+a5N4z6xenOrLbAyJzYAdgK4bIcIHzp0SF28eBHhcLglc97Ro0dx"
        "9epVY/W7B2AfgI8r9G2rJShXqW8A+JNSKsrMcuDAAdqzZw+SyWRTYjJjDDZu3IipqSlcu3bNaK21MebfAN4GcLfR5DU6rXGV2w3g"
        "90qpAev1qLu723PP7FqfDZnY5r33AbwD4J9ekOfFImjQLhDsV0r9kYj0yZMn6fz585ROpz11KMyMzs5OnDhxApOTkwIgy8zDAD6w"
        "c31xPWQixnq3fwHIGGM25vN5yWQyyGQynhNo82VmZqWUegbgo0Z522amcmwXOV9KxdzmZeq4RD4tWTrzBF4JbpfdL8/18KssfQJ9"
        "An0CfQJ9+AT6BPoE+gT68An0CfQJ9An04RPYTDTlsLWtEK2qsqDePj5zBCqlEAqFEAqFPF+R9rqPZhMoALC4uIhnz56hWXsitgTO"
        "7X/dFb4rq/QWAFkiEpSW1KWJzdh+n6BUeF7NMYy2skAB8LZSKszMfPjwYbVv3z5ks1lP90SYGZFIBJOTk2p6etoopWJ2V+63XhLY"
        "6H1hATBIRB+ISDwWi/HMzIwaHBxELpfzfAhHIhHcvHkT+/fv52w2q0TkIxH5JoDneLkwvaE33UjLEwC/VEq9pbU24+Pjenh4GJlM"
        "BoFAYFn9YCOb1hqO42Dz5s1gZrp+/bpRSsVEpADgL/BogynQoHmPUTpwc5KIfiAiHAwG1Z07d3Dq1KmmhhfusQZbmcAATgDIA/gV"
        "gHm0wQGbTwvGL1nFik12Gms6Fft6zoNR1xALdOeVAZRqUsrOwuvN9GqCamZm+/5LleFV23lhIjIiovr6+szY2BgikQiMMS0hkJnR"
        "0dGBx48f4+zZs5RKpRQRFb2YShoZxhAAhEIhDA0NIRqNNr24spLAcDiMBw8eVHp+TxQJ1DHv0UoEMjOSyWT5mEOrCMzlcktPB7jn"
        "iSt1l3pDm1oJXKnTAlA6HNPT04NoNArHcVpGYGdnJxKJRGX/jnUobXFW7k2USnqDFYS+AQALCwt05cqVls+BoVAIT548QT6fdxX4"
        "GoAfoVQ5JgByAP4K4EE9oU0tdxdEqeb4K0S0LLtw6/TaJsaqiApW0PHvAHbV450Dr0i2oFREPgDAiIi4pyM/ZV5sOUqx9LL5zq0Z"
        "HETpvPOLWq0wUONTZWbWw8PDMjo6Sl5XnzYqSmBmHQ6HMT4+TrOzs26yUtdwqYVA9+AytmzZgoMHD2Jubq58rredUSwWEYvFMDU1"
        "RbOzs1BKETOrZhPopkiYn5/Hw4cPMT8/35RjDPXCGINUKoVkMrnsXpqxnOXOEV8G8CGAUHd3N/r7+9vKaVSDR48eSSaTIQDPUFr8"
        "bcoig0t2FECizRYMam0fA9hQT6YSeMWhS/ZpHQXwbSIySq2//0VdWl8QAJi28WDbLXF9blCr9bRlzFejQ2TfDHz48OGjNvwPKVIC"
        "MJAgdkoAAAAASUVORK5CYII="
    ),
    "wn": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAARBElEQVR42u2cfXCV1Z3HP79znpvk5p0QguHFYHjZprBQoeAiLaCx"
        "u2hJoTgSB62BdtvKtl2w1a3WQqV1HWylYwWk3RWmVeluWaG7Ywdxi45LpZ3pLrWOFrdOKyoK4a2BvN+Xc377R54ne4lRSLhBtDkz"
        "dzLJffI8z/2c3/f3ds5z5V9W3fAEg6NPQ6wxxrvOKXPmfESAjw0i6dfQNXd8vkOGFRePG2TR9+G9D060tjYPkjiHUVAQmxwAMoii"
        "724Q0La2lAsAHeTRPx8IYAY5nNsYBDgIcBDgIMBBgBfW/bynUqtggGGYMNz7s0iXLODCY7tzrT9nC/RAOoSiZ7iWhMeNAa4BSsL/"
        "kT9Xt2CA64DHgDXAyLeZMAktD+AmEXlDRBT4H2DCBeyno4mdmO0TRzA+ElqQGmMUeA34aC9uIzp+VXQ8kAh/7rqA/eGAA/xUCKEz"
        "lLECzcDsDIjRsYvD91PGGDd8+HAFnIh4YFSPG77gAA6UPDpCKLa2ttaGQIpEZCswOsM3fkBEHhQRRMQ8+OCDZsWKFQBirZVwhm0I"
        "PHIN72u/GMnzmlC6qaefflrvuOMOBZLWWgW2A4VADNgWHpdeuXKlqqo+9NBDkQVq6Eff7jrm/Szhj4Zg/De/+U1/8uRJnTVrlgI+"
        "Fouptfb31toXY7FYyhjjx4wZo/v379djx47ptm3bNDc311trNQiCl6y1W0TkbqAOqMq4Rs+g9b4AKOGr1BjzW0AnTJiQfuONN/SZ"
        "Z57RgoICzQgW3a8NGzbo8ePH9fXXX9df/OIXWlhY+JZjgiBQa22riPxcRO4CZvVilXK+AdoBknE7MB6Y6b3X2tpaM2XKFEaOHEki"
        "kaCqqspXV1drVVWVLFq0iGXLltHe3o6qMnToUIqKigAYOnSoD4LAt7e3k06nVVVzgWpgrrX2RhG5VlUrgDeAExkq0PMEsEIGyALV"
        "GPOkqn6surraPfXUU1ZVicfj5OXl/f/BIqTTaVpaWk47SUFBAUEQ0NraSmNjI4cPH+b1119n3759unfvXn/gwAFNpVIBgDEG4Ij3"
        "fjPwAHAkQ9J+AAEqMFEGwAc6YK4x5j+997ahoUHWrVsnzc1d6y/en/6ZRARrTxeC9x5VjzGWWCxGTk4OQRCQSCRIpVI899xz7Ny5"
        "U5988kl99dVXFbDGGFT1TVW9FfjXHvfzngAYWV9MRP5LRC4zxrif/exndtKkSXR2dhIEfSu9VfU06CKCMYa8vDzy8vI4ePAgu3bt"
        "YsuWLf6ll17qBum93w78HXB0gCB2A7RZhueB+4MgWOSc8w0NDfamm24iJyeHnJwckskkImc/Z2F+iDEGY0z3/yaTSdra2igqKmLG"
        "jBksWrRIKisrzW9+8xvt6OhQY8xEYAHw38DBAfCL3T4wWwBNCO/rxpjbnXPugx/8oH3ooYdIpVJs376dkydPUlVV9RYJ9+vuQ6jO"
        "OTo6OgiCgJkzZzJv3jxpbGyUl19+2YnIMBGpBw4AL2R0hi44gDaEd4Ux5kfee19ZWWkeeeQRKSwspKGhge9///vs2LGDSy+9lAkT"
        "JvTZEs8EUlVpb2+noqKCBQsWYIwxe/fudUCeiCwCDgP7wgzBX0gAoxNZEdkmIiNisZjfuHGjmTt3LsuWLWP37t3E43ESiQQjRoxg"
        "7ty5WQPYE2QqlSKdTlNbW8vIkSPNnj17fDqdFhGZB/wW+N8sybkboMmSdFcaY6Z57119fb2tr6/n0UcfZefOnVhrSSaTAFRXV3db"
        "zID00bpSGk6ePElDQwP33XefMcaoMSZHRDYDHwgDStYqF5MFeKOMMV/13utFF10kK1as4MSJEzz66KOnSWzYsGHMmjWLzs7OrFpf"
        "b9ZoreXEiRPU19dzyy23GOecE5EKYHNYh0u2qpZznQkFVgPlqupXrFhhJk6cyPPPP8+LL77YDcp7z80338zYsWPp7OzstpSzTWXS"
        "6TTOuT5bY3NzM7fddhsLFy603ntnjLkcuCWbVtjfk0SB43JrbYP33k+fPt0sWbKEpqYmCgoKcM7hvSeVSjF79mw++9nP0tLS8pak"
        "+Yx1YRAwbNgwSkpK+iR9EemGf9dddzF69GgDeGPMPwBTwvs/5yBqz8GJWmCziIwH/He/+10zfvx4WltbqaioIAgCXnvtNebPn8/a"
        "tWuJx+M4585avqpKEAT86U9/4jvf+Q6HDh3iQx/6EKlU6qzPISKkUikqKioYNmyYPP744x7IA4bQtdzQ34Wrc6qFI9+32Fr7E+ec"
        "r6urM1u2bKGlpaU74c3JyeHYsWOUl5fjvSeZTPZJus45SkpKuP/++7n77rsZMWIETz/9NPn5+X2aiGgy4vE4ixcvZs+ePd5ai3Pu"
        "I8Cv+lmpdFcipp+SLxGRVapKaWkpX/7yl0/zUapKZ2cnZWVl3fVrX+BlWuAf/vAHgiAgPz+fVCrVL7l477HW8oUvfIHc3FxVVSMi"
        "X89IruV8+cCoXPuUiEzy3ruGpQ1mypQptLa2ngYpkk9UjvUnmqbTaQ4fPkw6nSYvL48hQ4b02foArLW0tLRwxRVXcNVVVxnvvReR"
        "vwamhZ/HnA+AEbyhxpjbVVVHjRplPvPpz9DW1tZrcOhvuuKco6ioiGeffZZf//rXAMydO5e8vLx+55Cqiohwww03RPIL6Fr84lwS"
        "674AjDL424CRquqXL18uo0ePzmploapYa/Hes379ejo6OsjJyeGTn/wk6XT6nJLs9vZ2pk+fzuTJk433HmPMQqAsNAwZSIBR4KgS"
        "kc94731NTY0sWbKEU6dO9Tk1ORPAoqIi7rnnHp566ilEhJkzZ3bnkP2dqMillJeXM3/+/KjZOhr4xLlkJH2xQA/8vYiUA7py5UpT"
        "VFTU5wT3TNItLS3lhz/8IevXr9dYLIaqUllZSXStc7F0ay1tbW0sWLBA8vLyvPceEflYhnuSgQAYWd8l1tq/9d7rjBkzZN68eW8J"
        "HOcy0uk0Q4YM4bHHHuNrX/saDMACURSYKisrmTp1qg3/NpuuvTh+oCww+iDLvffFgFu+fLnpTz72dpL13lNWVsZPf/pTvvjFL2oi"
        "kdDwPR9VI9maKOccBQUFzJs3L1q7GRVGYwbCAqNdUxXGmGWqqjNmzLC1tbVZsb4oMhYXF7Nx40aWL1+uyWRSRURU9R6gMbQSjUqz"
        "bFih957JkycTj8d9aASfGCiA0fsNQLkxRpctWybxeJwgCIjFYv3uMIf+h4KCAtasWcOqVat8GM2Nqt4O/HNYcpGfn581CxQR2tra"
        "uPTSS6muro4mcUZ/O9Zn2rPngUJjzPXee8aOHatXX301yWSSxsZGjh8/Tn5+fr9klJubS25uLl/5yldYv369N8aY0PJuB+4Fpjvn"
        "4gCXXHKJZMNdRACdcxQXF1NdXR2dsCqMyH1Oqs1Z5H1Twpded911trS0lNWrV1NbW8s111zD1q1bicfjZ2WJUXekuLiYI0eOsGzZ"
        "Mh5++GFnrTXe+2Oqem0IzxhjRqkqsVjMTZgwgUQikbVcMwomH/7wh8M50+HA2P5UZ+YMaQvA33jvrbXW19XV8ctf/pLNmzfT3NzM"
        "oUOHuO+++zhy5AhRyvFOkgUoLy9n9+7d1NXV6a5du5wxxjrnXgE+DuwAcrpY618CFBQU6Lhx47K+DOCcY9q0aaKqUW+wJttR2IcZ"
        "/GUA48aNk+HDh9PU1ARALBYjCILuBZ138lFRLSsifOtb32Lp0qX+zTffFGut9d7vAa6kawkyBiSBsjA/Y+LEiaasrIxsSTgzkFRU"
        "VFBSUiKhH4wisctmEMEYEwMoLS0FYNq0aYwaNap7AWfq1KlcfPHFtLW19SrjqC115MgRli5dyrp161wikTDGmKRz7ut0Pa/8Wo+2"
        "0gwRGQX4uro6E4/Hs76OkkqlGDp0KJMmTZIQ6vj+1MXBmXpe3vsWgJaWFtra2igvL+fHP/4xr7zyCsYYJk+eTH5+PoWFhaRSqdP2"
        "uXjvKS0tZffu3dx666168OBBH1rd7733XwJ+njGRLoQoIvJp7z0FBQU6derUc6qB38kHlpSUUF1dLXv37sUYc4n3PidUQFYARo7/"
        "MMChQ4e0vb2dMBpTU1ODiJBMJnnkkUd44YUXqKmpYfHixSSTSVSV4uJiNm/ezKpVq3wikRBrrXXO/ShsSBwLr+8y2usOuMwYM985"
        "p5dffrmZPHkybW1tWUtjMgNaTk5Ot7LCpkJlqAZztpVJcAZ5O1X9lTHm8ydPnqSxsZGqqiqam5tpa2ujsLCQbdu2sXLlytNmd8mS"
        "JQD84Ac/4M477/RhVFXn3FeBb2dE+XSPDm8ArPPe5wH+5ptvNtkG19O9VFZWRmrJA/4iBJjVUu750KzN1q1bNR6PU1hYSBAE5Obm"
        "sm/fvu6EGODll1+mvLycnTt38o1vfEOlaxz33i8K4UlGhZOZMnngjiAIZqmqv/76683s2bOzWm/3bG+l02lGjx4tXV7FizGmz6nM"
        "mVo4AhwH/kpExv/ud79zra2t5uKLLyYvL4+mpiZ27NjBH//4x+4ouXr1ajo6Oli6dKk2Nzd7Y4xT1UXAzjDK9nxqKQgt8XpjzHrn"
        "nB85cqTZtGmT5OXldVcs2R5RGem9Z/v27T6RSBi6nk955iwk3L2o9E4Sjp4uSqvqHcBVQGzDhg1u69atlJWVaXt7O0ePHhVjjPXe"
        "c/XVV1NTU0NdXR2NjY3OGBN47+8EdofwUr1MYBq4TET+CZDc3Fz53ve+JyNGjOjXMmhfK5Ly8nLi8bg/deqUBS7qa018piAS9cie"
        "p+t5jo3GmBFNTU3d+WBU7EcXXbRoke7fvz9trY055zaHsg0y/F0mPAeMF5GfGGOKnHN+zZo1pra2lhMnTvR5P2F/csF4PI4xJgJW"
        "0qOIOPconGGJ/w48672/XkSqjTEjVTXmvT+pqjcAsSeeeCK8N4k5556ga5NjlJxqL/AqgH8zxlQ559yNN95oly5dSlNT04DCy5Rx"
        "5MvDGy8N803PWa4Zn+1dRkX2cWCDqvbsRA8FPhGuwHV473cAy6Pg02NGo5xvGPAf1topzjl37bXX2nvvvTerNe/ZdqmHDx8uBw4c"
        "iFKZOF0PCkm2LLCnnDOfFpJQmp8GPq6qTlX3A8/16Oj07G6XA49bay9zzqUXLlwYPPDAAzjncM4xkKlLb1IeMmRI9HmG0LX5qCOb"
        "Eu4p595qxRPAw71EKe2lPVYAbAvhuQULFgQbNmzAOUc6nT6v8KJInJFMx8NgR7YlfDZt/6j9pb044e4N6MBPrLVXOOfS8+fPDzZu"
        "3Njd5jqf8DItMD8/P5rwWF+ZZAug9hJle2vOftsY83HnXLq2tjbYtGkTqtqvrR/ZHFFTWERy+srkfNx15PeuMsZ8yXvvampq7KZN"
        "m7rXat9NeCJCPB7PNCh7oQFUwIjIWsDE43FZu3atlJaWkkgk3lV4GRKOfs290Cww+m6uxeEeal9fX2/mzJlDc3PzgFUZfR0ZFpjT"
        "I4i8qwC7V/tFpD7cMOQ/97nPve1mpHdrhJWI9ofJ+QA4SkTmAMyZM8eMGzfuvCfLZ0xwT++kZ60jnQ2AAJcYY4Z47/2VV15pohr0"
        "QgCoqtHOCH2b3PVdBRjJY7r3Xo0xOmbMGIIgIAiCC0LC3vve7kX7AnIgAUb7W8aqqhQVFWGt5ejRo3R0dLzr0TcCmEqlMjtLesFZ"
        "oKoWA669vd2tWLGCnJycC0rCxhiOHTsWAe3zAzjnwwcmAeucs6+++ioX8lDVZF8aCQMNMApt/wicAkqttY4L8HtfvPeqqhZ4kq7H"
        "Y4WB+7qAwZFhBBOD83Sx98oXPWpfLS84Tzfl3q+mOPgVoIMABwG+p8f/AV+IUqL0iuqeAAAAAElFTkSuQmCC"
    ),
    "wb": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAQY0lEQVR42u2ce3Bc1X3HP79z776k1WP18GIJ28XGBgciHEwhBEdA"
        "myHEIWhICCFlmvEEcGomnYZJC2ZoUlqKMx3H06lnEkjpTIjdzNTMmAkNTToVxqDEjBuCTWIyfoBjCduybCxp9drVPu759Q/du17J"
        "Lxl7FavoN3NmV7p7zz3ne37v8ztXUnt/9iwzdI6kBsRa6316BovzoL7fvTRPVLe6M1CcI70K3AIitxZmwDgfQda/MzMozNAMzdAM"
        "XbwkMwP8YGMKxmVP8fcMnYEmugWxs1yf4cAJY1GgEnjIdd1PAlerare1doeq/ivwdsnvZugUnPVx4NfGGPVBKjYROQ789cW28HKR"
        "gKdALfArEblcVfNLly515s6dSzqdZuvWrZrL5RwRQVXvBjb7983oxBLue9rnvNxXv/pVPXz4sA4ODurAwIBu2LBB4/F4XkQ8Efk9"
        "MNdf/A99KBVIQLUxphewS5Ys8To7O/XgwYO6b98+feedd3RoaEhXr16tQN5xHAX+zL/Pudis3h8KwCZjjAPINddcIw0NDWQyGcLh"
        "MI7jkE6naW1tDX5vgeYgnv+wAxgAcAwYBUin0+TzeT/boVhrERGGh4dLx9xzsejwiwFAAfo8z9sjItrR0aF79uwhmUwSCoWIx+OE"
        "w2E2btyogFFVD/jtjOk4QYEe+0vfiHgLFy7U5557Tt944w1tb2/XL37xiyoiBRFR4JdAdEKE8qE3JCHABf5NRDzAAzSRSAR+oPU/"
        "3wEu8+9xLobBXyxGJO+HbbuAVCgUEkD7+/sB1HVdcRzHAm+WiL53sYD4hxZdgM+LyK7SCCQWi2lLS4vOnj27+D9jjBpj+oAngeqS"
        "fj50ohxwfhLY6Pt2Cnh1dXW6atUqfe211/Tw4cO6e/duXbdunS5ZsiTgOnUcR0VkJ3DzRZ5ZKovIBpz3mRKus/F4vHD//ffr66+/"
        "rr29vdrd3a0HDhzQrq4u7evr0/379+vatWt1wYIFFij4HDkKPO4blYsyW3OhwQu45FHfWCiQX758uW7ZskV7e3v18OHDun//fj1w"
        "4IB2dnZqZ2envvvuu9rV1aW9vb26d+9efeyxxzQcDnuBWAP/A8z+Q4DoTPGzLPAPxpgnVZWKigr78MMPu9/5zndIJpMMDg5ircUY"
        "g584QEQwxqCqxejkU5/6FEuWLJGdO3dqb2+v5zjOQlX9BPAzYGgqxVmmEDwP+LYx5u+ttbahoUGeffZZaW1tLQLnOCfWU1VxXRfP"
        "88Z73qp4nkdVVRWpVIqVK1fy2muveY7jOJ7nbQfuAHqZoryhM4Xg3S8i/6yqNplMysaNG+Wmm26iv78fx3EwxowDKRQKcfz4caLR"
        "KI7jFEO6gCOz2SwVFRW0tbWxd+9es2/fvoLjOHNVdTHw4lSluswU9O8Bi0VkvYhoJBLhmWeekeuvv57e3l5cd3xlied5VFdXs2nT"
        "Jm6//Xa+/vWvI3KyoDiOQzabxRjDM888w4033uh6npc3xnwOeNh/rpnOAAazjojId0Wkwlqr3/rWt0xrayt9fX2EQqGTg2NfdHfs"
        "2MHRo0fZtm0b6XR6nHgXB28MuVyOcDjM2rVrSSaTrqqqiDwCLJkKEMsNoAXuNcYst9Z6bW1tZuXKlQwMDJyS84KWz+dxXRcRIRqN"
        "UigUitcKhQKqOo4T0+k0ixcv5qmnnhLAikg1sMYPD8uq600ZwVMgJiJ/Y63V+vp6eeSRR04yCgElEgnq6upIJBLU19fjum4RqJqa"
        "muK1xsZGQqHQSSCmUinuvPNObr/9dsda6xljPg18khNbo2WhcpW2Ob6ze5sx5iOe52lbW5u56qqrOH78+DjuCwzGD3/4Q3bv3l38"
        "u6OjA4BUKsWjjz5KRUUF1loqKytZsWIFs2bNIp/Pj9OPIsLXvvY1Xn75ZTzPM8CDwNbp6MYEHLgB+HPXdb329nZn0aJF5HK5kyad"
        "zWZpaWlhdHR0Up0//fTTfOlLXypa8ICstUSjUe69917b0dFhHMd53/O864FOyrQJZcoIXtQYcx3ARz/6UTNv3jwKhcIpjUYkEuG6"
        "666jtraWRCJBbW1t0cCICFVVVcVrs2bNoqmpiUKhcJJ1ttYSi8VYtmyZjHWtDcBV5VRX5axOXWiMudJay8033yw1NTWkUqlTWlMR"
        "4Uc/+hGDg4MUCgVqampYvXo1L7zwAnV1dbzwwgvU1tZSKBSIxWLE43HS6fQ43zHQhZlMhltvvVXWrFmTt9aGgBuB/yqXU+2WkQMX"
        "qKoAOnfuXHEcZ5zin8g5ruvS0NBAoVCgsbGR2tpaAEKhEM3NzcRiseIeibWnl0RrLbNnz6aurs709fUhIvP855bFsS6XCGOMSXqe"
        "h4hofX39KUVuoigXCgUKhQL5fJ58Pk8Aej6fL/7/dFa8FMBQKEQymRSfuxtLFlWmA4ABhQLxDIfDp+W+iaIsIjiOQ2VlJf4CEI1G"
        "i4mFMy1CaT8lTnqonPMspw4cFhGstTI8PHySvjqt/+M4DA0NsWLFCpqamrjyyitxXfesHFwKnud5DA0Nqc/Zw35EMm0AVF+U9voT"
        "l56eHs6kAycCkMvlmDNnDg899BCe55HJZCYFXnB/Op3myJEj1vdH3y2RtmnhxgQovW2tPQjw6quv6uDg4Ckt8JlAHBgYYGRkZNIP"
        "DvzAV155RUdHR4NipO3lVFflAlCAYWvt/wLa0dFhu7q6iEQiZ7SgE0GcmOaaLIgvvfSSjtkx08+JTfhpY4WDfhXYYIyRfD4v69ev"
        "L8awkxHlc6V8Pk9tbS0///nP2bZtm/r692fAXspYCleuhGrAhV3Ax40xC/bs2eNdcsklprW1leHh4SKQF6JZa6mtreXgwYOsXLnS"
        "9vf3Y4zJqOoqoLuc2elyWmEBRlV1NdBhrY09/vjj1nVd84UvfIFwOFwU1fOhIFO9a9cuvvnNb/Lee+9ZY4xrrf0X4A3KXIhZ7j2R"
        "YPD3ichzquoCtLa2cs8995BMJosAnDOL+35hPp9ny5YtPP/88wTukrX2x8AKTpSETOua6kDP3iUihxgr4yid2IVqnjFmBPg+EJki"
        "BpkyCsKCT4hIynVdeyFBdBzH8yu3/qkEuCkBT6boGcJY8dB/GmP+xFprL7/8cvONb3yD6urqYsh2riLsOA4vvvgimzdvVl90B4DP"
        "MVYCNyVF6O4UAWiBxwLwWlpaZMOGDcybN498Pn/Ovl4AIMDy5ctpbm6W9evXW2NMrbX2+8CtQB9TsDc8VUakxRjzK2ttqL6+Xn76"
        "05/K/PnzGRgYmHR0cjoQjTHU1NTwwAMP8JOf/KTgW+BvM1bBVXYuLDeAwab6syLyAOCtW7fOefDBB4vbmufjVPvOMuFwmO7ubj77"
        "2c9qd3c3wFFVvZopqFAotx/oAXERuU5VtbGxkY997GO89dZbRTfkQpDneSQSCZYtW8amTZvEcZxLPM/7Y+C/pzuACiRUdQ4gqVTK"
        "3HPPPUXuuZAhnZ+FEcB6nifAgnJmYaaCAuV2JydKcnUKWt7//HEJgDIdOTCgaxg7LKj33XffaXfUzjv49lXCpk2b5NChQ4jIFapa"
        "AaSnO4AZx3HwPI+7776btrY2enp6iqUbk03Tn86NCdJjoVCIUCjE5s2bg2TGKGOb+9PeD/z1WL2P2CeeeMJEIhFZunRpcZMom82O"
        "K107XYIhACzIwAT7HtFoFGMMR48eZc2aNXR2dnqAo6q/A3KcKOycdm5M0HclY5WjnwRsRUWFLl++3Nxxxx1y9dVXM2fOnGIBUaFQ"
        "wFo7LlVVyqVBkjUcDmOt5dixY+zbt4+Ojg6ef/5529XVZUXEVdUMY4WWr5S4UtPSDwwscT3wj8aYvyjJSHuXXnqptLS0SGNjoyxa"
        "tIj58+dTUVFBLBajoqKCSCRCoVAgk8mQTqfJZrMcOXKE3bt3c+TIET1w4IDu3LkzyD0aP5zbBjwCvM40Pd0exL7Gb6WhxpdF5JfG"
        "mNGSow2lp9LVcRwNhUIajUY1FotpNBrVcDisruvqaU6yB+dH9gDfBapKEhimpJUlwfBBOyx1DUrzbZNd7TnAnzqOc0PINTfHK2KL"
        "B0cymsvlzzoeMUZr4xVYa/uHM9mXVXWHtXYL8NYkjYacYrG9qTIiAWd5Z+ivGoj7uq/Cz8KEfY4IDglmjSFmre11xN3XWBtfPJr3"
        "sHYM/1MVIQX6T0Q0UR03+Vz26OBI5j0RMcClwCX+87O+L5j3LXEaGPHbsP/JhAUPshm2nBxY6tHPYqzq6SMicq2INIvIJSJS5wMV"
        "9icTNMPYUVVTaiBOR83Nzdxyyy2sWrWKbdu2sXHjRt5+++0zRiElLTicaP2FLvhgFoC8qqZV9T1V7VfVNxg7Y7Lzg0Ytco7gVQGP"
        "iMi9InJ5UAXwAangOI6Gw2ETj8edK664ghtuuIEFCxZw7bXXsnDhQjKZDJFIhIGBAbZv386BAwd48803+c1v3uLYsfdtLpez+Xxe"
        "/UU6Z3Xkp9EKqrpZVdcxtociJSm4CwJgYMkuY2ybcplvST0A13VJJpNy2WWXUVdXh4iIMaZ4WKbUr4vH49TV1VFVVUV9fb3MmjWL"
        "ZDJJQ0MD8XicqqoqIpEI2WyWXC5XPN5gjCEWi2GtZWhoiJGREVKpFD09PRw7doz333+fgYEBHRwcpLe3d9zec+nOnapqOp2ms7OT"
        "np6eoPzD8cFUa+3f+2kwO1lulEmC1wy0A4sBr7GxUb7yla+YpUuXMmfOHOrr65k9ezbV1dVnjSyC8rRSUc7n84yMjDAwMEAqlWJ4"
        "eJhdu3axfft25s6dS2trK7W1tVRXV5NIJKiqqiIcDlO6UMH3M5G1lmw2S09PD319fRw8eJAf/OAH2t7e7nmeF9iDfwf+arIJWZmE"
        "OxIF/sMY8zlVLdx2223u9773PZqamhgZGWHv3r3s37+f48ePa/C+g1wuRyaTYWhoqKjrQqEQ9fX1VFZW4jgOo6OjjI6OkkqlyGaz"
        "pFIpuru79dChQ0FOr3TgUl1dzbx586S5uZn6+nqJRqNUV1cTj8eJRCLF4sr+/n6Gh4eL2Z5oNFp8bUAkEiEcDpNIJGhqapKWlhYS"
        "iQQ7duzgySefZOvWrdbX078FvgzsPpt3IZNIhrb4R0ttLBYzq1evNgsWLOAXv/iFtre328OHD+vo6OgFPbN7Ki6ebEnIpFNFjuPV"
        "1NToTTfd5Nx1113S39/PE088wdDQUFZEIqr6FPC3Z4tkZBLcWeGnhto4cfz+pJfe+JP2AgvovyQnUPAO4ASi6zvAXtCAnKoOqeo+"
        "Ve1V1aOMvSfrmC8BV4vIXBGpE5F5ItIEhFXVVVXHj33NBEtc8JuqqqOqJvidXzk7bn0mGMzjwGeAX59NF05WByaBtcDnHcep9MUj"
        "Y619E9guIjustcO+n5Xz/a8gG1Ll+4TRkj7zQMZvaX/AfefgiFf6rlTc9zMrGL8XXPDHMuRzT9S/HvO/Vxpj/khVl4nIdcaYS4ND"
        "jIy9VuBRYMv56sCJIALMBxb5K/J74KDvuJYjFJz43sBzjXYmS7P9edX789nnO9uTiqPlHCalZ4g+JjM5OUUEwCnCwXNxv+QMc9FJ"
        "3Oud5neTdqjlA3DG+Uz8Yk18/H+a0wzN0AzN0JTR/wHu6hnDZdovgAAAAABJRU5ErkJggg=="
    ),
    "wq": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAXdklEQVR42u1ce3BVRZr/fd3n3iQ37wcJCUl4BElIcIKAOAbYURhG"
        "ZMEH4OjI+tqyBAWldBYdXEvZmdHa1aqtGUdrxNIZS/9BZ6t2S9ex1rJqrd2al/NwcXgnIIHwCobc5D5yH6f72z/SfTxcbl4kqFND"
        "V506J/fec073r7/v9/366+7Qzu13vue6iiSBcamMqSgGEYClABzgEoAXUMiZNKmokxMsiOgSgGMszEyXUBivCZrjUrlULpVL5VK5"
        "VMZc5Fe0XiIjuIm/1mBHpvFjAUCM8PdfTRGjsKyh7plORC9LKfc6jnNQCPERgC1mxDQa6UXGuxxzpr9EywOAfAALALQBKBkl4HMB"
        "dJmhpXeYkdKbBpDhOkKM8fOvpMsCwP1EdMJxnKTjOGkhRB+AHwDIzQKAtaoSAHsAsBAife2116q1a9eqpqYmBSBlwNw+DCCW0wsA"
        "XA1gJYDFAIr/UkC0FXwy04J8x8+yjIJswx8QQjARudu2beP+/n7u7+/ngwcP8oIFCxQARUTdAGqzAGKvv0ZEfxBCpIQQLIRwiegT"
        "AF//qoNoQVgshFAA3MmTJ6sHHniAt2zZwrNmzdIA0kIIBnBnxj0OABDRcwBUeXm5+9vf/paPHTvGe/fu5Z6eHn766ae1tUxDC/77"
        "LSgtAE75Okv5rnuy3Dfu4kxkcsKA8AAzi6KiIvf111+XbW1tICLceeeddMstt9Cnn37KQoiHtdZvICOFRkRRZqZ0Os2JRALBYBA5"
        "OTkgIkSjUfuzBICBDPdnAAEAzwOoCgQC6bVr1zqtra1iz549/Itf/MJNJpNlAHYAWGLuJ3wBKTzLaTLLdbagIYQQ7wPglpYW9/jx"
        "49ze3s579+7laDTKS5cuVQBYSrkfQGEW3lxtLFRt3ryZjx49ygcOHOA//elPPGvWrLRx4b0AirLc2ySlVADUli1bOBaL8cmTJzke"
        "j/P3vvc9BqCklAxg/ggqIbOtYjwWyBm9xBkv05l/M/MpAHzq1CmdTCZlcXExXNdFMplEJBKxzxsAEDX32M8IwH9prf8bwLUvvPCC"
        "+8477zhSSkSjUe7u7naICMz8rwD6TeOUr/MaiIgA8Ny5czEwMICenh4QEb7+9UH601prIcQcrfUfhzAWPcq2jggg+R5ymxDiDiKq"
        "BpBQSn0E4GkAZ3wPZtMgzcy7iOiO3t5efv7553HrrbeCmfHhhx9i165dmoikUupjc4+/YsJE2jsBvALgus7OTv7cu8ll5mfMd2TA"
        "85fTFoTTp0+jsLAQyWQSpaWl6OrqguFPqZQ6PgR/KwAriGiDEKIeQFpr/YnpsP3DgThUNHUA/NTor8zjIIB5Ga5go2olgL3md2ki"
        "shrOAt0NoCmjozI7zgHwE3OvIqLTAFYN4Xr2nkIiOgiAa2tr3RdeeIFfeeUVfumll7ihoUEB0OY5lRn1tff/IxG5Wdp6FsDqsURw"
        "G6HutSDU1ta6y5YtcxcuXOhaPUZEuwCUZlTCnmcD+JXhMw1Am+t9AK4doTJBc77PF0k/A1DuGxYOJZ9WArAg6CxgrMtooz2vsJ1c"
        "VlaWXrp0qdvW1qaCwWDatPX0ENIpq+sSgFIhRAcA1dzc7O7atYvD4TD39PTwo48+ykSUMi/cau4LZGlMboYe7PNZnhxFB75m7kuY"
        "80jA28//logOE5E24CsiOgpgTZb7yUS+3USka2tr3ffee48jkQj39vbyjh07PC8ytDWiBLJffk1K2QeAH3zwQd3f38/79u3zomJB"
        "QUHKVOwnQ3CpBXSxsQRljnW+6DYc9+YC+JX1AHP+h1E0wL73Yd/w7wCAycOAn+84zikA/O1vf1vH43Het28fHzlyhDs6OnjGjBmu"
        "8aD/GM340JJ2nJkHACCVSjEzw3EcEBFSqZSdjSIAsSEaos33RX6JA2CzdekRAKwwNIDBwAr4OHc473EB5FhrY2YAiBgKEEPoPteo"
        "AmZmTqfTCAQCEEJAa410Og3zrGg23hZDNPxTAGEA/MEHH/CRI0eQm5uLnJwcvP3224jH40IIQcy8dwQJpDLe02aSBTyCJdUZftXM"
        "LHy8Knx1HMoYFphxsMoIiHoI0JNa68MA6De/+Q12796NUCiE3NxcfPDBBzh27JgiImLmXaMdxdgfbLbEWl9fn7rmmmvcefPmaTNM"
        "YwC7DLFnSy/ZZ3zLkjkRWVccjkvsZw8B4FAopKZOnap80bthBBEMAC+b39vkwx+NVWKYet5ERHEAqqSkRC9ZskS1tbWl8/Lykqbu"
        "xwHMyhDuo0oK/JCIVEYks38vHwUQ3/JFQ9cQe0fGSOK8+6SUbwDgmTNnups2bdI+t185BOfa59QAOGPkjzsKAP11fcMYTGZ7j5jh"
        "X9aOEyNw2BPMvIKIXhRCvC2E6PRVYmMWxZ7dpKVEaWmpYGYmogYf+Nk4mABcDgA1NTVYs2aN5TYyVjCc19wGoIKZ1ShXDQgDWCOA"
        "a039tBDi91LKnUT0TyYQ/u9YhfRQAD+aERnXD2GF51iglJLvvfdeXVVV5RpB+04Wd7DXU6WUJ01UVEeOHOFQKOQaV/p5FkuyFJID"
        "4PdExOXl5e6cOXOUGX0MZ4FWV76bkbVpHm0ydiR/1gYMW4FdGWPkpw0P6qGeRURQSmH+/PlYtGiRICISQlxjUk86S0qqUWtdaRIS"
        "lJubi+bmZjLPmmukCmcR721SyvnMzHfffbdsaGjAMG4LX2C51SfAAaAXQLupTyDLGHnMaW7lc6Hjxvoc8/lUAP+c0aBswhxKKdxy"
        "yy3EzK7WugDADUO8b6aJvGru3LmUn5+P1tZWC+AsE53Pi/hEtEEpRfn5+XrFihWe/BhB8tQAeC6Dhj41bSSfp2E8APot7jMDIvl6"
        "5m4Af2MAHTLEJ5NJLF68GHV1dZKZQUR3mWGb8icHiGgeAIRCIaquroYQAtOmTbOdEzIyyJ/K0gAahBDLiYgXL14sWltb/fnD4dr9"
        "fSKakiGNDo6W28cKIAyAh21gkFKCiBwi2mEal6nRvHRYKpVCZWUlbr75ZjLcNAvACl892Fh2KwDMnj2bioqKkEgk0NDQgEAgoJRS"
        "EELMyzLDd7PWuoyZ1W233UYZApyHyLysAnA3M6tAIODH4ZPxTj0OBaBjpMgJAJg8ebK+/vrrBTMrImoC8LgvRXWeC9tRzMqVK5GX"
        "l6eVUiCi9RlAFAshGgGgtbWVysrKEI1G0dLSgoqKCpvxbvE9WwHIIaJ7mRkzZ84UixYtQjKZhBACQwQcDaCIiJ4lIpmfn0833HCD"
        "H/R9I3DnuKf6DgFAOBwW69evR0tLi2BmLYR4xLhXVlcWQiAej6O1tRVXXnmlICIQ0XUApvkIfK7NVE+dOpVycnKQTCZRVVWFSZMm"
        "kRlSzTJjZXvPdQZ0XrNmjZg0aRJSqdRw7WUAjwshZjOz2rhxo2hoaGAAkohiZk5lwl3YeyAz7xZCIBaLyb6+Pjz11FNkOC0PwAsm"
        "Yg8ZtYgI69evJ2ZWZrpxrQ/keUopSCn1jBkzkEqlQEQQQmD27NnWImaa1JJt9N8ppVBQUKBWr16NgYEBv/VlG/e2EdEWpZSaPn26"
        "2Lx5M373u99ZsI6aRPGEu7C/R/YJIVIAsHv3br7pppuwevVqoZRSQohFJo/oDgVeMpnE1VdfjWnTppHWGkKI9SaYEBG1AkBFRYVu"
        "bm5GIpGAEAJEhIULF1rRWwag3rhYkxDiegB8zTXXyKamJiQSCT//ZVJJEMCzRJQrhKDt27dTUVEROjo6tDEOmwOgi2GB1qoOm5eg"
        "u7sbsVgM27ZtQ1lZmdBaMxE9bZT9ec8nIiQSCdTX1+Ob3/ymMPJjjsn1MTM3GgAxZcoUpNNpDwyj62yjrjDX3zGSSN9+++2ktR5u"
        "fM8AviuEWKS1VjfeeKNYvXo1Ojo6EI/H7e+O+PieLxYHDmitDwFAR0cHnzhxAi0tLdi6dSuZvFkxgH8ZikeklIjH41i3bp2NrNJo"
        "wskApgNAU1OT8Luh67qYNGkSysvLSWttBXWulPI7zIw5c+bQwoULh7I+YdJVDUS0VWuty8vLxeOPPw4iwsGDB9Hf3y9MB7ePhf8u"
        "BEBL5PsA4NChQxyLxRCNRnH77bdjyZIl1pVvNOq+N5sbp1IpXH755bj66qsdw3HrAFxnRDJfddVVwgJhf19TU+PxoBBippEh0wHo"
        "G264QVRUVHicOYSGfZ6ISgHwtm3bqL6+HlprHD58mJVSQkrJWusDGd424QBKA+AeIkJfX5/u7+8HESEYDOKJJ56gvLw8Mq75rHHl"
        "84YESink5eVh3bp1NulZCWA7EQmfu3oAptNplJeXo6amxsqN2UT0Q6UUFRUVYe3atYhGo3CcrJOMfQDuE0Ks1FrrJUuWiPXr16O/"
        "vx9SSpw6dcq+J4nBdTm4WEHEX6ypi8OHD8NxHEQiEcyfPx8PPPCAMMGhBcD3ASSzSZpYLIZvfOMbqKurg9YaUsppWmuUlJRQZWUl"
        "XNc9bzw9c+ZMMvO7nl5ctWqVqK2tzSZdrCnOIKJnmZkLCwvpqaeeIn8dzJQnmPkkgJMX2wItN5wkogQA+ec//5mFEB63bdy4EU1N"
        "TWRGDVMxuFIKAIiZrcUhkUigtrYWS5cutdzIzIzGxkZUV1cjkUiAmaG1htYaAwMDuOKKKyClhNaamVlLKbFq1Sov/W7T+OYdFsA6"
        "IipiZrrvvvto3rx5iMViCAaD6O3txf79+9l0Sns2b7lYAB4jopMAcODAAbaEn06nUVJSgu3bt1suYj+XBQIBBINBBINB5OXlgYhw"
        "1113IRAIQClFANDY2Ij6+nrk5OSgqKgIhYWFKC4uRk5ODubPn4/CwkIAIK21WLBgAZYvX450Oo1QKIScnBwEg0EEAgGPCw23cXNz"
        "M+6//3709fVBCAHHcdDf34+jR4968uxCMBnr4iKbtuo25j69u7ubE4mE55qRSAQrV67Ehg0b8NJLL5GU0gO3t7fXW26hlAIzQ0qJ"
        "2bNn45NPPvF+98tf/hJdXV2IxWJIJpNwHMcDSKnPFyTMnTsXx48fRyQS8SaChBAIBAIeBWitqaioCD/+8Y9RU1ODzz77zPvu7Nmz"
        "SCaTmogkM+8ZaRnHcLNgYwXdlVK+rpS6o66uTr377ruyuroaqVQKAwMDOHDgAPbs2YMnn3zSkxb19fXIzc3F2bNn4bouXNdFIpGA"
        "67oIBAKeC1qXHS677Y+0rutCCOFZtuM4yM/PR29vL2KxGMwYGZs2bUJ+fj6am5tRV1eH0tJSvPrqq3j44YdZCEFa6+UAPrDtu5gA"
        "SgBKCPGE1voHwWBQL1u2TKRSKZw8eRKxWAyfffYZYrEYHMc5JxiM+UVSQggB13U97hxPMVMLKCgowPTp09He3s5dXV1ERGFmXmyi"
        "sMT5624mFEBr4msA/NtIzwkEAggEAqisrMS0adNQV1eHgoIC5OXleW7pOI6XHgsEAigoKPD40gKYSqWQTCYRjUahtYZSCq7rIp1O"
        "I5FIIB6PY2BgAOFwGIcPH0ZnZ6dHAcNYtE187AVwFQZXjI1p3eB4Flh22JeFQiEUFhaiqqoKU6ZMQXFxMWprazFt2jRcdtllqK6u"
        "Rl5enudmlqvsYYOMWb4GrbV39n9HRJBSetZoI651e2Y+B+xIJILOzk60t7ejs7MT3d3d6OnpwbFjxxAOh9HX12c5tQ/nLrfDxbRA"
        "20OlRPQJM0+prq7mV199VTQ0NKC4uBihUOgcC7EBwzbSD4AX3n3XWUYTI/7OH+1tAsJG20Ag4Inss2fPIpVK4Y033sAzzzyjAEit"
        "9Ytm1cSY3HdUs+zDuPEAgMlSysX9/f0qGAyKtWvXeuQ9MDCAVCrlgZcNNL9l2WPE3vMBNNx9tsOsi9shZ15eHqLRKB577DEOh8N2"
        "HniTT0TjYlugPzFZC+APRFTJzPpHP/qRuOuuu3DmzBkvAPitIdNds11n+yxbB2S6cTa39p9ttA8EArjnnnvw/vvvu0IIR2v9cwB/"
        "j3NXy150AP1zC6uJ6N8ByGAwyDt27KBbb73VI/VUKuVZQTQaRTKZRCqVQiKRQDKZRCKRQCqV8o50Oo1kMol0Ou1ZsF+AW6Fsr+2a"
        "nZycHOTm5noiPT8/3/ttTk4OQqEQUqkUNm3ahLfeeksJIaTW+vcArjdJjzGDN14A/SDeSUQ/Y2YqKSkRW7duRW9vL9rb29HT04Oz"
        "Z896EifTajItaEyVz0IB9qioqEBVVRVKSkpQXV2NlpYWHDx4EK+99pqWUgqt9UFmXm6y0Be06mCiio3k3/UtauSJOszK1ok67OKo"
        "Ll/Sd1x7RiZiE55/icaviWihEEI5jiPN7B0aGxs9a8jLyzuHHy1HSilRVFQEKaWnC+3ZRnIb2VOpFCKRyDkjF3u4rov+/n6Ew2Ec"
        "PXoU+/fvx8DAgNWOSmstTcR90aw8SH/ZAPrFdZsQ4n2tdV59fT3t3LmTSktLPcFsx6vZAkemzPEf2VzUjrGzBRQrn6LRKIQQePvt"
        "t/HII49oIYRg5v9h5usMcBrj3GwzUTuV7BqXX2utnwHwdFdXlz506BCtWLEC4XAY6XR6WJ7zg5MpUzIj60i86Qe5oKDAzroRgB5m"
        "3oDBddcCE7BTaSK3etmZrz1EBK21CIfDXFBQYHODWQOIdT2/8LaROplMelHYRlobWa17+2kgUwbZbE9PT4+d8D/pW5rCExkAJgxA"
        "IcQMrTUcx1GO48gPP/wQ3d3dOH36NLq6unDq1CmcOHECZ86c8TjMD6YF0p5NthqO45wzZs60Uikl6uvrUVlZiZqaGtTV1aG8vBxV"
        "VVWoqKiwVDUVg4s7o/iC9sqNBTxLSm8SETuOky4vL5/ICHpBh+M4XFpaykIIZVagrp6I6HuxgshjRPSMbxX/56buOCgtLUVZWRkm"
        "TZqEwsLCrC5YVlbmuarN71mXdl0XkUjEy/P5o286nUZPTw96enrQ29uLvr6+obLpJzC46vTIROg/mkDwbgHwFgDOzc3FVVddRc3N"
        "zWhsbERlZSWKi4u99HxJSQny8/Oz8leWuY3zuE0IcV5gSafT6OvrQ19fH/r7+72js7MT+/fvx8cff4x9+/ZpIhLM/J/GEsftxjQB"
        "FswY3Kd2AMDkkpISfvnll8WyZcuQTCa9+Qmr4/wcl5lcyIykw2VismVh/NrRWrd9p5QSDz30EHbu3MlSSlJKzcYFbCKc6CBiAbxS"
        "CFGtlOINGzaIlStX4sSJE95MXWZDbXZ4oovWGslk8hywbeeVlZXhxhtvxJtvvgmlFAshrjAT6eMyookAEES0VCnFwWCQ29raKBKJ"
        "eBbwhUayYVJbAHDmzBkrzElrnT8RUViM816Fwd1HDwNAfX09NTY2IplMjiq390UC67oupkyZAsdxtPlsIwbXIurxWKGcAPfdKKVc"
        "ysz6ueeeE3bi2ojprLm60WSexzRZnZHZzgwwdiK/qakJkUhEfPTRR0oIMYWZf4XBNdHyQq3RGa/7YnBjIgBwd3c3iMjLy9k0ulLq"
        "vEG//8jkrNGClTn8y0xS2M8sNzqOg6VLl+LFF1+076n4MnWgzQVeBuD/AISCwWDqyiuvlFVVVXTZZZdRfX095efno6ioCDk5OV6i"
        "MxQKIRQKeRNNtuFDpf6HylbbiJ5MJr0EbiwW82bj4vE4IpEIwuEwOjo6uLOzk9vb23VHRweMnJlv6j7muZCJljF3YHCDdLbdnwBg"
        "s8IcCoXOATEYDJLdSpufn4+CgoJzss5SSkqlUmwz1KlUCuFw+JzhXiKR4Hg8jng87geQfHtFsm2I/CmAB3315C8DQL+QXk5E9xBR"
        "LYBaIppMRHnMfM5yjC86ePimQXuY+SQzH2fmjzD4b6jS4xXTEz2UAwbXIZeYCFcGYJoQopqZawBUElEFgMlE5ODzvWoOPv9PaxKA"
        "w8z22kZ7ZXZg2t3vrjkUBvcVawBxIjqhte4hopNa65Mm+9yFwbnfCMzy5AwP+tLHwn5JpC+QT4MmQxz0XQfMd2lzpLKceRz8/ZVJ"
        "JmTLC470Hv8sGE/A+4ZqS7Z/HMQT2divSjpsNPXiUX52qVwql8qlMpry/+ah4C7H1pb0AAAAAElFTkSuQmCC"
    ),
    "wk": (
        "iVBORw0KGgoAAAANSUhEUgAAAFAAAABQCAYAAACOEfKtAAAT8klEQVR42u2ce2wd1Z3HP+fMffr6HTv4HRscZxNI/IKEdEFQAhUP"
        "FVMKqULKdmnFwtLVLq26uFIpG0pXSAhoF0SXJbDUCY9oG5ylqCAUoN5EG4KKEhKCNzjGduzYkDi2r32v7fuac/YPz0zHxkmcxCmm"
        "9U86unPnzuPMd36P7+93zrniaMu/6+CiyjdTsXgPQkgphGJeZi4H/mvDc1prOY/EmYmwN7T+vYcW4Mp5UE5LtP4XqbUW80jMy7zM"
        "y7zMy7zMy7RUa54lnC1PnasgGl8CEHMALxCf16eZi51aLgE+AnYCuXNZE+cScF4gYH3+PaCtdq21zw945gqQnjkGoLJa0vo+bH0H"
        "CLv2zxnxzCHNU8CFwHVAyPp+icuc7wGusb4PAa8Ch13nztMU4H9cJnuq9p9T/OVfrAZqCwQNfADUWxolXD4PIAakXOcdmA8q00sV"
        "UGN9PujSuLuAvwJqgfPnfeCJpc213e3aPgQcnKt8a675RK/VN59rv9/a55lLZjsXAdQuSpNw7Y+7oq2eB/DkfUpaaWaJa3+Z9Zma"
        "o/2eU7n55UCLYRhKSqkMw9BSyjjwWyu9+7Lk8V8IeDcAo1JKbZmsw/2sfT1WJJ4TFiTmkNkqYBXwphAiS2ttNjQ0GNdccw3JZJLm"
        "5mZ27tyZklJ6lFJdwNVAh/UMf9GZiK1FQWCvYRgaSN1777362LFjenBwUIfDYd3V1aVvvfVWDSQtTdxmgfdn4w/thzGmafIk2m6b"
        "7j9awKRuvfVW3d/frzs7O3V7e7s+1H5I9/T06MOHD+uvfOUrGkhJKU3g6yfxh2fanzPyO7NxnVPlrm7i/jkaIqV8XClVUlpaqp9+"
        "+mnp9/tJpVIYhoEhDVKpFGlpaSxbtoxXX31Vx+NxQwgB8IorFRQugNQM+3NWlMgzC8CZVgNYDJQC+da1h4Be4Bjw6ZRc1gZdAUuk"
        "lDVKKbFmzRpZXl5Of38/Hs8fu2cYBpFIhLq6Ourq6kRLSwuGYaw2TTMPGLTul3L1JR0oBIqBBZaLiAIDVhWn29UfOQXYcw6gbR6m"
        "dY21QohvCyFWCyGyJ7FirTXQpbVu11q/Y1GRVutcr9XpC03TTANYvHgxpmliadfkm1r7lixZIlpaWtBa51l58XHrRaQDVwkhbhRC"
        "1AHnCyGypvQH4FOt9QGt9XbgJeslcyalMc8ZgqctAL4uhLhPSnmZaZp258xptLQCqDAM4xqt9Qal1GvAU0CLK+uY2FDKvs6JU5XJ"
        "vw8BGcCdQoi7DcNYnEql3MeY0/S/ECj0eDzXmKZ5n9b6BWADEwVcY5pzZg1A4WoPSinvV0phmqZesGCBuuiii+SqVauM4uJifD4f"
        "/f39fPLJJ7qtrU23tbXpgYEBAfiFELdIKb9pmuZvgbuBY0IIpbWW8XgcKU8eWGOxmO3vhoGbhRB/I4RYppQilUoRDAbN0tJSKisr"
        "5ZIlS4zi4mIyMjIYGhqip6eHnTt3qp6eHj00NASQJ6W8Vym1CvgB8N7pgOg5A/AU8Esp5T8ppXQwGFT33HOPsW7dOqOsrAytNVJK"
        "hBBorTFNUwghRFdXF83Nzfzud7/jwIEDpmmaUgjRANRorbdIKYeUUgt6e3uRUp5UC48cOSIsk84VQvyr1trQWqcKCwuNdevWiauu"
        "usqorq7G6/U6fbH7Y2m47OzsZOvWrWzatEn39/eblj99HbgF+P1Mzfl0Qrl9wX+WUj6ilEpVVlYaTz/9tLj44ouJRqMkEolJZub2"
        "Yz6fj1AoxPHjx/nDH/7AM888o1taWhRgSCkxDCOVTCY9l156KS+++CKGYUy6htYaj8fDwMAADQ0NHD58GI/HQyqVIhQKqTvvvFN+"
        "97vfpbS0lHg8zvj4+KSXMF1/MjIyaG1tpbGxkR07dphSSkMpNWTRo/+dCYjGaYK3XEr5slLKKCsrk1u2bBHLli1jcHBwkuYJISZt"
        "CyEwTZPR0VH8fj+LFy9m3bp1IhAIyB07dmittRBCSK01Q0NDNDQ0cN5555FMJp2HNk2TrKwsdu3aRVNTE4YxQW0uuOACnnvuObF+"
        "/Xq8Xi+RSIRUKvW5+0/Xn0gkwsKFC/nGN75BR0eHPHjwoGkYRprWug7YZEVpMVs80CuE2CiEWOrz+dRTTz0lV65cyeDgIF6vd9qo"
        "OTWCSilRShGPx4nH41xxxRWsWLFC7N69m5GREXw+H7FYjJqaGmpqaojFYo45e71eRkZG+NGPfkRfXx9KKS666CI2bdpEdXU1Q0ND"
        "aK0xDOOUfbH7YxgGiUQCKSUNDQ10dHTI1tZWU0pZpLVOA950UZwzNmHboa4xDOMt0zTVddddJzZv3izC4fAkrna6YmtVZ2cnd911"
        "F3v27EFKydKlS3njjTecY7TWZGVlcffdd/Ob3/wGgJqaGpqamigoKCASiZx1P/x+P/F4nGuvvVa1t7cjhIgqpS6xKuQnNGU5Q8oC"
        "8G3TNLUQQn3ve98TpmmeMlqe8s0YBuFwmNLSUjZv3kx9fT1KKT766CN++tOfEggESCaTZGZm8qtf/coBr7KykmeffZbzzjuPaDR6"
        "VuDZ/YjH4/ZLklprBWQC3zyVos0EAQUEhBCXAKKsrEyuWLGCmdCNGdEAj4doNEpubi4vvPACy5YtA6CpqYlXXnmFkpISDh48yGOP"
        "PYaUkuzsbDZu3MiiRYuIRqMYxuxko0IIEokEK1euxO/3C6WUtqpDnCyQyBlG6XIp5RKAG264QWZnZ5NKpWatCuHxeBgdHWXBggU8"
        "8cQT5OTkIITggQceoLW1lY0bNxIOh1FK8ZOf/ITa2lqGh4fPWvOmA7CkpITVq1dLQBiGUXsqHzhTFVokhPAAuqioCL/fj1KzW4Lz"
        "eDyMjIxQV1dHY2MjWmv6+/tZv349zc3NE2Xqyy/ntttuY2hoaFbBswFUSpGens7ChQvtfVlMzA47oRnPFEC//Rbi8fisg+f2RcPD"
        "w9xxxx2sWbMGgI8//tgJEvfccw8+n++c3N+mYWNjYxw/ftzeZ54qI5kpgP12JmL7vZlQhTPRAjtbaGxsxO/3Oz7ukksu4atf/SqR"
        "SGTW/N5094/FYgwPD2sLwMNMTGriRGZ8KgDtk9qVUiMAe/fu1ePj47MSQKbtkKUF9fX1rF+/HtOcUIDbb7/9nN3T1kCv18vRo0dp"
        "a2vT1svcNxtRGOC4UmoXoN98803V2dmJ1+s9ZdXkbGX16tXOdnl5+Tm9l1KKQCBAU1MTkUhEWAD+9lQ4zUQD7cJns5RSxONxsWnT"
        "JjIyMhztOFfmFI//cVZvMpk8p+AFg0E6Ojpobm42Aam1brWKCuJsaIzNgQSwVWvdKYSQv/71r9Ubb7xBZmbmOQdxuu1zYb6BQIBH"
        "H32UoaEhO338peX/zprG2LW3Ia31fVYk1vfdd5/u7+8nEAjMSlTUWk9qUwurU3+fLUmlUuTm5vLkk0+yZcsW0zAMQyn1NvC8q+p+"
        "1lHYnsO3VWv9smEYRnd3t/njH/8YIQRer/e0QLQBMk2TVCrllPANw8Dr9eLz+QgEAvj9/knlJ6/Xi2EYSCknnTuTKvaJcuD8/Hxe"
        "euklNmzYoKxy1mfAP0wZvznrgqp2FVS/b5rmBVLKla+99pophDB+8YtfEAwGGR8fn5Zi2IDZpSSPx+MA4vV6icfjRCIRxsbGSCaT"
        "xGIxotEon332mXONgYEBBgYGSCaTBINBsrKy8Pv9JJNJkskkiURiEph29edEPg8gNzeX559/nsbGRlMIIbTWY1rr25mYRjfrBVV3"
        "XbACeNUwjOWmaabq6+s9zzzzDOXl5QwPDzt0xH4Yv9/vmHoikWBwcJBDhw7R2dlJd3c3g4OD9PX1EQ6HGR0dZWxsjFgsxujoKIlE"
        "Aq01+fn5ZGVlEQqFyMzMpKioiLy8PEpKSqioqKCqqorc3FyHO8ZiMWKx2OeANE0Tn89HMBjkiSee4Gc/+5kCpBV1/w7YeDol/TPx"
        "zDaIpcDLhmH8tWmaqdLSUuOhhx4S119/vaMVaWlpeL1eOjo6aG9vZ8+ePbz11lv09PQQDocnVbDPRrxeL9nZ2RQVFXH11Vdz8cUX"
        "U1lZyfnnn49pmoyPj5NMJpFSkpmZyfHjx3nooYd48cUXTSmlobUe0Vp/H3jhdAeVzjS02TdZALxgGMa1pmkqgJtvvlk2NjZSUFBA"
        "S0sLW7Zs4eOPP6ajo+NzFwkGgwSDQUKhEMXFxeTk5JCVleW07OyJEdJwOMzw8DAjIyMMDw8TDoc5cuSIo63j4+Ofu3Z5eTlVVVV8"
        "61vfYs2aNWRlZZFIJHj99dd5+OGHdVtbm2nNszkM3M7EYh7BaY4Nnw03sEEMAf8mhLjD4k86Ly9PFBcXs3///knOPT09nVWrVlFd"
        "XU1VVRXl5eUUFRURCoXweDxOgLCb7U/tgKOUcloymWR8fJy+vj66uro4dOgQ+/bt49133yUSiUzqaH19PbfddhvvvvsuW7duNe1x"
        "GKVUK3ArE+PUnpkGjtkCkCmO9nohxKNCiKVWLU0AZGdnc+mll3LTTTexdOlSysvLyc7OJhaLOaZ+prTEZgBer5dAIMDIyAidnZ20"
        "tbWxbds2du/ezcDAwOfOsarN/wE8zMRMhdMy29kE0L6GzZeWCiE+AkRWVhZr165l7dq1VFdXO1o0NjbmBBafz4fP50NrTTKZnKRh"
        "bi5oj3O4tdPj8SCldCKwHTDS0tIm5tMYBgcOHKC5uZmXX36ZoaEhpbWWpmm+ATwAvD+NEnwhAOJK90oNw2g1TTPthz/8oX7wwQdF"
        "OBwmmUw6muLz+RgfH6e3t5fPPvuMo0ePcvz4cbq6uhgcHCQSiRCJRBgfH2dwcNChG4FAgPT0dDIzM8nJyaG8vJyFCxeSn59PQUEB"
        "JSUlpKWlkUgkHM02DIP8/Hwef/xx7r//fuXxeGQqlVoBfMjEtJIUX/DkIjdPnDQB3OfzOZzNNE2OHTvGvn372L59O52dnXz66acc"
        "PXqUWCx2yot3dXWd8Defz0dBQQGFhYWUlpbyta99jdraWvLy8khLS3Nenjtou0z2rFOac7ZOJBAI0NvbS1NTE3v27OH9999nZGTk"
        "5FVbv5/s7GwCgQChUIisrIl5QSMjI0SjUbtWNwn0RCJBd3c33d3dvPfee2zdupX09HR7Fhff+c53CAaDU1+2ySxNzJwtE7b9yCIh"
        "xEda69CFF16ow+Gw6O3tnXRgeno6lZWVlJWVUVJSQmVlJeXl5WRkZDiE285UAoEAwKSAE4/HHZLd1dVFe3s7R44cobu7m/b29s+9"
        "pIKCAvLz8/nwww+VNXhfB+xllhYpzjaAFRYlCLjSP7Kzs1m9ejWXXXYZK1asoLa21jHtqUUC9z475XLPKrADirvZmce+ffvYt28f"
        "u3btYteuXVMjsLL6OacBrAI+tsFbsmQJDQ0NrF27loKCAkKhkJPn2nNd3PzPRTOc5q7EuPNYO6rbRQWtNenp6QSDQcbGxjh27Bhb"
        "t25l27ZttLa2fmkArJBS/p9Syn/jjTfqRx55ROTn5xONRh3NCoVCjnMfHh52oq6dadjZhp1x2BqcmZnpZCgZGRnOp71tR/fR0VFn"
        "gCoUCjE8PMyGDRvYvHmzklJKpdSsAjjbQUQJIZKAv7q6mry8PEZHRx1zjUajbN++nb179zI4OEhXVxddXV309fWddl7s9XopLCyk"
        "vLyciooKcnJyqKmpYfXq1WRmZmIYBmNjY+Tk5FBXV8fmzZudAsdsyrmIwo5Wp6Wl8cEHH7B//37efvttPvzwQ3p7e09axZZSOgEk"
        "FAoBOPluIpFwAEgmk0703bFjh2P+JSUlLFu2jKuvvprly5dz5ZVXntOxlFmPwlLKj5RSoYaGBp2dnS1eeeUVotHopINzcnIoKiqi"
        "uLiYiooKysrKSE9Pd0pVPp+PtLQ0MjIyAIhGo4yNjTl1w2g0yujoKD09PXR0dNDb20tfX59DvN3FiltuuYVkMsmWLVvOiQnPOoBM"
        "rCRPd0dhgKqqKurr61m5ciVXXHEFOTk5GIaB3+93ZpLagcFdsbb9mR2J7W27oBCPxzFNk+HhYXbu3Mnu3bvZu3evHTimG9upY2Jl"
        "/JwEcIlVzTWllEIIIevr6/n5z39ORUUFeXl5JJNJJx+eOtZxskGk6WabuiO1EIJgMIjP52NgYICenh4eeOABdu3ahdZaqQnb98x2"
        "FJ7tIX7NxJSwPEBorU2PxyNCoZDIzc0lFAo5WmcP6NilfrtIMJXGnKi5gbQrzEoph2C/88477N69Ww8ODir+uPjmU+AxJtaLzCkf"
        "iKsYWQDcBtzJxH8cAGi/329WVVXJm266SdbW1lJUVMSiRYsIBoOkUikHTPcYytTg4tY2r9eLx+MhFovR3d1Nb28v+/fvZ9u2bfrg"
        "wYNmLBYzXM/3CfAs8DITi2xOu3D6pwBwquQDfyuE+IGUstAVeRVASUkJixYtEoWFhSxfvlzU1dWxYMECh1i758WYpun4ulQqRTgc"
        "Zs+ePezfv1/39fXR3d2tu7u7J400GoaBUuqY1vpJ4DlL++ZsFD5RfRAgC7hGCNEghLhCCFE6zTCkCWgxIRiGQV5enkhPTwdgdHSU"
        "/v5+7Urz3OviHK20BsQ/1Vq3aK1fA7YzsYrJdleKWf67gHOpgdKtcXZuD1wuhLhZCFErhMgDsrXWxukSXAswBYS11gNa6w+01v/N"
        "xOqnvlP040sB4FSN1FMews/EOrfzmFikuMTS1gwgJIQIMrFAECCmtR4HRoEIMGLl3IeAo0AnMDYFNHEuNO6LAHA6rRQzGIOQU7RH"
        "zeB4Mc2L4s8JwKn3dje3tugZnOdeoqr5gv4KZa7+75Q4Cc+cl3mZF0f+Hz1BzO5bj2HaAAAAAElFTkSuQmCC"
    ),
}

if __name__ == "__main__":
    root = tk.Tk()
    ChessApp(root)
    root.mainloop()
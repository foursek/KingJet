import chess

PIECE_VALUES = {
    chess.PAWN: 100,
    chess.KNIGHT: 320,
    chess.BISHOP: 330,
    chess.ROOK: 500,
    chess.QUEEN: 900,
    chess.KING: 0,
}

def evaluate(board):
    if board.is_checkmate():
        return -100000  # side to move is mated
    if board.is_stalemate() or board.is_insufficient_material():
        return 0
    score = 0
    for piece_type, value in PIECE_VALUES.items():
        score += len(board.pieces(piece_type, board.turn)) * value
        score -= len(board.pieces(piece_type, not board.turn)) * value
    return score

def negamax(board, depth, alpha, beta):
    if depth == 0 or board.is_game_over():
        return evaluate(board)
    best = -float("inf")
    for move in board.legal_moves:
        board.push(move)
        score = -negamax(board, depth - 1, -beta, -alpha)
        board.pop()
        best = max(best, score)
        alpha = max(alpha, score)
        if alpha >= beta:
            break
    return best

def best_move(board, depth=3):
    best, best_score = None, -float("inf")
    for move in board.legal_moves:
        board.push(move)
        score = -negamax(board, depth - 1, -float("inf"), float("inf"))
        board.pop()
        if score > best_score:
            best, best_score = move, score
    return best

board = chess.Board()
while not board.is_game_over():
    print(board, "\n")
    if board.turn == chess.WHITE:
        move = None
        while move is None:
            try:
                move = board.parse_uci(input("Your move (e.g. e2e4): "))
            except ValueError:
                print("Illegal move, try again.")
    else:
        move = best_move(board)
        print("Engine plays:", move)
    board.push(move)

print(board.result())